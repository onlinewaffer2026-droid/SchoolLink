// dashboard.js - عرض المحتوى والدرجات (قراءة فقط) للطالب/الأهل

// حالة الصفحة
const PageState = {
    currentTab: 'feed',
    selectedTeacher: null,
    academicYears: [],
    messages: [],
    teachers: []
};

// تحميل الصفحة
document.addEventListener('DOMContentLoaded', async function() {
    // التحقق من تسجيل الدخول
    if (!window.AppState.currentUser) {
        window.location.href = '../index.html';
        return;
    }

    // تحديث معلومات المستخدم
    updateUserInfo();

    // تحميل المحتوى الأولي
    await loadInitialData();

    // تهيئة علامات التبويب
    initTabs();

    // إضافة مستمع للأحداث
    setupEventListeners();
});

// تحديث معلومات المستخدم
function updateUserInfo() {
    const user = window.AppState.currentUser;
    if (user) {
        document.getElementById('userName').textContent = user.full_name || 'طالب';
        document.getElementById('fullName').textContent = user.full_name || 'طالب';
        
        if (user.current_class_name) {
            document.getElementById('currentClass').textContent = user.current_class_name;
        }
        
        if (window.AppState.activeAcademicYear) {
            document.getElementById('activeYear').textContent = window.AppState.activeAcademicYear.name;
        }
        
        // إذا كان هناك اسم مدرسة
        if (window.AppState.schoolInfo) {
            document.getElementById('schoolName').textContent = window.AppState.schoolInfo.name;
        }
    }
}

// إعداد مستمعي الأحداث
function setupEventListeners() {
    // تغيير فلتر المحتوى
    document.getElementById('contentFilter').addEventListener('change', function() {
        filterContentFeed(window.AppState.contentFeed, this.value);
    });

    // تغيير السنة الدراسية
    document.getElementById('yearSelector').addEventListener('change', async function() {
        const yearId = this.value;
        if (yearId) {
            await loadGradesForYear(yearId);
        } else {
            showNoGradesData();
        }
    });

    // إرسال رسالة عند الضغط على Enter (مع Ctrl)
    document.getElementById('messageText').addEventListener('keypress', function(e) {
        if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            sendMessage();
        }
    });

    // إرسال رسالة جديدة عند الضغط على Enter (مع Ctrl)
    document.getElementById('newMessageText').addEventListener('keypress', function(e) {
        if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            sendNewMessage();
        }
    });
}

// تحميل البيانات الأولية
async function loadInitialData() {
    try {
        // جلب السنوات الدراسية
        await loadAcademicYears();
        
        // جلب المحتوى التعليمي
        await loadContentFeed();
        
        // جلب المعلمين
        await loadTeachers();
        
        // جلب الرسائل
        await loadMessages();
        
        // جلب الإشعارات
        await window.Helpers.fetchNotifications();
        
    } catch (error) {
        console.error('Error loading initial data:', error);
        window.Helpers.showToast('حدث خطأ في تحميل البيانات', 'error');
    }
}

// تحميل السنوات الدراسية
async function loadAcademicYears() {
    try {
        const user = window.AppState.currentUser;
        if (!user) return;

        const { data, error } = await window.EduPath.supabase
            .from('academic_years')
            .select('*')
            .eq('school_id', user.school_id)
            .order('created_at', { ascending: false });

        if (error) throw error;

        PageState.academicYears = data;
        populateYearSelector(data);
    } catch (error) {
        console.error('Error loading academic years:', error);
    }
}

// تعبئة اختيار السنة الدراسية
function populateYearSelector(years) {
    const selector = document.getElementById('yearSelector');
    if (!selector) return;
    
    selector.innerHTML = '<option value="">اختر السنة الدراسية</option>';
    
    years.forEach(year => {
        const option = document.createElement('option');
        option.value = year.id;
        option.textContent = year.name;
        if (year.is_active) {
            option.textContent += ' (نشطة)';
            option.selected = true; // اختيار السنة النشطة افتراضيًا
        }
        selector.appendChild(option);
    });
}

// تحميل المحتوى التعليمي
async function loadContentFeed() {
    try {
        const user = window.AppState.currentUser;
        if (!user || !user.current_class_id) {
            showNoContentAvailable();
            return;
        }
        
        // جلب المحتوى للصف الحالي
        const { data, error } = await window.EduPath.supabase
            .from('content')
            .select(`
                *,
                classes:class_id(name),
                teachers:teacher_id(full_name, subject)
            `)
            .eq('class_id', user.current_class_id)
            .order('created_at', { ascending: false });

        if (error) throw error;

        window.AppState.contentFeed = data || [];
        displayContentFeed(window.AppState.contentFeed);
        
    } catch (error) {
        console.error('Error loading content feed:', error);
        showContentError();
    }
}

// عرض المحتوى التعليمي
function displayContentFeed(contentList) {
    const timeline = document.getElementById('contentTimeline');
    if (!timeline) return;
    
    if (!contentList || contentList.length === 0) {
        timeline.innerHTML = `
            <div class="no-data">
                <i class="fas fa-book-open"></i>
                <p>لا يوجد محتوى تعليمي متاح حالياً</p>
            </div>
        `;
        return;
    }
    
    timeline.innerHTML = '';
    
    contentList.forEach(content => {
        const item = createContentItem(content);
        timeline.appendChild(item);
    });
}

// إنشاء عنصر محتوى
function createContentItem(content) {
    const item = document.createElement('div');
    item.className = 'timeline-item';
    
    const isLesson = content.type === 'lesson';
    const typeText = isLesson ? 'درس' : 'واجب';
    const typeClass = isLesson ? 'lesson-badge' : 'homework-badge';
    const icon = isLesson ? 'fa-chalkboard-teacher' : 'fa-tasks';
    
    let attachmentHtml = '';
    if (content.attachment_url) {
        const fileName = content.attachment_url.split('/').pop();
        attachmentHtml = `
            <div class="attachment-container">
                <a href="${content.attachment_url}" target="_blank" class="content-attachment">
                    <i class="fas fa-paperclip"></i>
                    <span>${fileName}</span>
                    <i class="fas fa-download"></i>
                </a>
            </div>
        `;
    }
    
    item.innerHTML = `
        <div class="timeline-item-content">
            <div class="content-type-badge ${typeClass}">
                <i class="fas ${icon}"></i> ${typeText}
            </div>
            <h4 class="content-title">${content.title}</h4>
            <p class="content-description">${content.description || 'لا يوجد وصف'}</p>
            ${attachmentHtml}
            <div class="content-meta">
                <small>
                    <i class="fas fa-user"></i> ${content.teachers?.full_name || 'معلم'} 
                    ${content.teachers?.subject ? `(${content.teachers.subject})` : ''} |
                    <i class="fas fa-calendar"></i> ${window.Helpers.formatDate(content.created_at)}
                </small>
            </div>
        </div>
    `;
    
    return item;
}

// تصفية المحتوى التعليمي
function filterContentFeed(contentList, filter) {
    if (filter === 'all') {
        displayContentFeed(contentList);
        return;
    }
    
    const filtered = contentList.filter(item => item.type === filter);
    displayContentFeed(filtered);
}

// عرض عدم توفر محتوى
function showNoContentAvailable() {
    const timeline = document.getElementById('contentTimeline');
    if (timeline) {
        timeline.innerHTML = `
            <div class="no-data">
                <i class="fas fa-book-open"></i>
                <p>لا يوجد محتوى تعليمي متاح حالياً</p>
                <p class="small-text">سيظهر المحتوى هنا عندما يضيف المعلمون دروساً وواجبات</p>
            </div>
        `;
    }
}

// عرض خطأ في المحتوى
function showContentError() {
    const timeline = document.getElementById('contentTimeline');
    if (timeline) {
        timeline.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>حدث خطأ في تحميل المحتوى</p>
                <button class="btn btn-outline btn-sm" onclick="loadContentFeed()">
                    <i class="fas fa-redo"></i> إعادة المحاولة
                </button>
            </div>
        `;
    }
}

// تحميل الدرجات لسنة محددة
async function loadGradesForYear(yearId) {
    try {
        const user = window.AppState.currentUser;
        if (!user) return;
        
        const { data, error } = await window.EduPath.supabase
            .from('grades')
            .select(`
                *,
                subjects:subject_id(name),
                classes:class_id(name)
            `)
            .eq('student_id', user.user_id)
            .eq('academic_year_id', yearId)
            .order('created_at', { ascending: false });

        if (error) throw error;

        displayGrades(data);
        
    } catch (error) {
        console.error('Error loading grades:', error);
        showGradesError();
    }
}

// عرض الدرجات
function displayGrades(grades) {
    const container = document.getElementById('gradesContainer');
    if (!container) return;
    
    if (!grades || grades.length === 0) {
        container.innerHTML = `
            <div class="no-data">
                <i class="fas fa-chart-bar"></i>
                <p>لا توجد نتائج مسجلة لهذه السنة الدراسية</p>
            </div>
        `;
        return;
    }
    
    // تجميع الدرجات حسب المادة
    const subjects = {};
    grades.forEach(grade => {
        const subjectName = grade.subjects?.name || grade.subject || 'مادة غير محددة';
        if (!subjects[subjectName]) {
            subjects[subjectName] = [];
        }
        subjects[subjectName].push(grade);
    });
    
    let html = '<div class="grades-summary">';
    
    Object.entries(subjects).forEach(([subject, subjectGrades]) => {
        const average = calculateAverage(subjectGrades);
        const gradeClass = getGradeClass(average);
        const gradeLabel = getGradeLabel(average);
        
        html += `
            <div class="subject-card card">
                <div class="card-header">
                    <h4 class="card-title">
                        <i class="fas fa-book"></i> ${subject}
                    </h4>
                    <div class="grade-summary">
                        <span class="badge ${gradeClass}">المعدل: ${average}</span>
                        <span class="grade-label">${gradeLabel}</span>
                    </div>
                </div>
                <div class="card-content">
                    <table class="grades-table">
                        <thead>
                            <tr>
                                <th>التاريخ</th>
                                <th>نوع الاختبار</th>
                                <th>الدرجة</th>
                                <th>الدرجة الكاملة</th>
                                <th>ملاحظات</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${subjectGrades.map(grade => `
                                <tr>
                                    <td>${window.Helpers.formatDate(grade.created_at)}</td>
                                    <td>${grade.exam_type || '---'}</td>
                                    <td class="score-cell ${getGradeClass(grade.score)}">
                                        ${grade.score}
                                    </td>
                                    <td>${grade.max_score || '---'}</td>
                                    <td>${grade.notes || '---'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    });
    
    html += '</div>';
    container.innerHTML = html;
}

// حساب المعدل
function calculateAverage(grades) {
    if (grades.length === 0) return 0;
    const sum = grades.reduce((total, grade) => total + parseFloat(grade.score || 0), 0);
    return (sum / grades.length).toFixed(2);
}

// تصنيف الدرجات
function getGradeClass(score) {
    const numScore = parseFloat(score);
    if (numScore >= 90) return 'score-excellent';
    if (numScore >= 80) return 'score-good';
    if (numScore >= 70) return 'score-average';
    if (numScore >= 60) return 'score-poor';
    return 'score-fail';
}

// تسمية الدرجة
function getGradeLabel(score) {
    const numScore = parseFloat(score);
    if (numScore >= 90) return 'ممتاز';
    if (numScore >= 80) return 'جيد جداً';
    if (numScore >= 70) return 'جيد';
    if (numScore >= 60) return 'مقبول';
    return 'راسب';
}

// عرض رسالة لا توجد بيانات
function showNoGradesData() {
    const container = document.getElementById('gradesContainer');
    if (container) {
        container.innerHTML = `
            <div class="no-data">
                <i class="fas fa-chart-bar"></i>
                <p>اختر سنة دراسية لعرض النتائج</p>
            </div>
        `;
    }
}

// عرض خطأ في الدرجات
function showGradesError() {
    const container = document.getElementById('gradesContainer');
    if (container) {
        container.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>حدث خطأ في تحميل النتائج</p>
                <button class="btn btn-outline btn-sm" onclick="loadGradesForYear(document.getElementById('yearSelector').value)">
                    <i class="fas fa-redo"></i> إعادة المحاولة
                </button>
            </div>
        `;
    }
}

// تحميل المعلمين
async function loadTeachers() {
    try {
        const user = window.AppState.currentUser;
        if (!user) return;

        const { data, error } = await window.EduPath.supabase
            .from('users')
            .select('id, full_name, subject')
            .eq('school_id', user.school_id)
            .eq('role', 'teacher')
            .order('full_name', { ascending: true });

        if (error) throw error;

        PageState.teachers = data || [];
        populateTeacherSelector(data);
        
    } catch (error) {
        console.error('Error loading teachers:', error);
    }
}

// تعبئة اختيار المعلم
function populateTeacherSelector(teachers) {
    const selector = document.getElementById('teacherSelector');
    if (!selector) return;
    
    selector.innerHTML = '<option value="">-- اختر المعلم --</option>';
    
    teachers.forEach(teacher => {
        const option = document.createElement('option');
        option.value = teacher.id;
        option.textContent = `${teacher.full_name} (${teacher.subject || 'بدون تخصص'})`;
        selector.appendChild(option);
    });
}

// تحميل الرسائل
async function loadMessages() {
    try {
        const user = window.AppState.currentUser;
        if (!user) return;
        
        // جلب جهات الاتصال (المعلمون الذين تبادل معهم الطالب رسائل)
        const { data, error } = await window.EduPath.supabase
            .from('messages')
            .select(`
                id,
                sender_id,
                receiver_id,
                content,
                created_at,
                is_read,
                sender:users!messages_sender_id_fkey(full_name, role),
                receiver:users!messages_receiver_id_fkey(full_name, role)
            `)
            .or(`sender_id.eq.${user.user_id},receiver_id.eq.${user.user_id}`)
            .order('created_at', { ascending: false });

        if (error) throw error;

        PageState.messages = data || [];
        displayContacts(data);
        
    } catch (error) {
        console.error('Error loading messages:', error);
    }
}

// عرض جهات الاتصال
function displayContacts(messages) {
    const contactsList = document.getElementById('contactsList');
    if (!contactsList) return;
    
    // استخراج جهات الاتصال الفريدة
    const contacts = {};
    messages.forEach(msg => {
        const otherUserId = msg.sender_id === window.AppState.currentUser.user_id ? 
            msg.receiver_id : msg.sender_id;
        
        if (!contacts[otherUserId]) {
            const otherUser = msg.sender_id === window.AppState.currentUser.user_id ? 
                msg.receiver : msg.sender;
            
            contacts[otherUserId] = {
                id: otherUserId,
                name: otherUser.full_name,
                role: otherUser.role,
                lastMessage: msg.content,
                lastMessageTime: msg.created_at,
                unreadCount: msg.is_read || msg.receiver_id === window.AppState.currentUser.user_id ? 0 : 1
            };
        }
    });
    
    if (Object.keys(contacts).length === 0) {
        contactsList.innerHTML = `
            <div class="no-data" style="padding:20px;">
                <i class="fas fa-comments"></i>
                <p>لا توجد محادثات حالياً</p>
                <p class="small-text">ابدأ محادثة جديدة بالضغط على زر "جديد"</p>
            </div>
        `;
        return;
    }
    
    contactsList.innerHTML = '';
    
    // تحويل كائن الاتصالات إلى مصفوفة وترتيبها حسب الوقت
    const contactsArray = Object.values(contacts).sort((a, b) => 
        new Date(b.lastMessageTime) - new Date(a.lastMessageTime)
    );
    
    contactsArray.forEach(contact => {
        const contactItem = document.createElement('div');
        contactItem.className = 'contact-item';
        contactItem.dataset.userId = contact.id;
        
        const timeAgo = window.Helpers.timeAgo(contact.lastMessageTime);
        
        contactItem.innerHTML = `
            <div class="contact-avatar">
                <i class="fas fa-${contact.role === 'teacher' ? 'chalkboard-teacher' : 'user'}"></i>
            </div>
            <div class="contact-info">
                <h4>${contact.name}</h4>
                <div class="contact-last-message">
                    ${contact.lastMessage.substring(0, 30)}${contact.lastMessage.length > 30 ? '...' : ''}
                </div>
                <small class="contact-time">${timeAgo}</small>
            </div>
            ${contact.unreadCount > 0 ? `<div class="contact-unread">${contact.unreadCount}</div>` : ''}
        `;
        
        contactItem.addEventListener('click', () => openConversation(contact.id, contact.name));
        contactsList.appendChild(contactItem);
    });
}

// فتح محادثة
async function openConversation(userId, userName) {
    PageState.selectedTeacher = userId;
    
    // تحديث واجهة المستخدم
    document.querySelectorAll('.contact-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.userId === userId) {
            item.classList.add('active');
        }
    });
    
    document.getElementById('conversationTitle').textContent = userName;
    document.querySelector('.message-input').style.display = 'block';
    
    // جلب محادثة محددة
    await loadConversation(userId);
    
    // تحديد حقل الكتابة
    document.getElementById('messageText').focus();
}

// تحميل محادثة محددة
async function loadConversation(userId) {
    try {
        const currentUser = window.AppState.currentUser;
        if (!currentUser) return;
        
        const { data, error } = await window.EduPath.supabase
            .from('messages')
            .select(`
                *,
                sender:users!messages_sender_id_fkey(full_name)
            `)
            .or(`and(sender_id.eq.${currentUser.user_id},receiver_id.eq.${userId}),and(sender_id.eq.${userId},receiver_id.eq.${currentUser.user_id})`)
            .order('created_at', { ascending: true });

        if (error) throw error;

        displayConversation(data);
        
        // تحديث الرسائل كمقروءة
        await markMessagesAsRead(userId);
        
    } catch (error) {
        console.error('Error loading conversation:', error);
        showConversationError();
    }
}

// عرض المحادثة
function displayConversation(messages) {
    const messagesArea = document.getElementById('messagesArea');
    const currentUser = window.AppState.currentUser;
    
    if (!messagesArea || !currentUser) return;
    
    if (!messages || messages.length === 0) {
        messagesArea.innerHTML = `
            <div class="welcome-message">
                <i class="fas fa-comments fa-3x"></i>
                <h3>بداية محادثة جديدة</h3>
                <p>لا توجد رسائل في هذه المحادثة بعد</p>
                <p>ابدأ محادثة جديدة الآن</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    let lastDate = null;
    
    messages.forEach(msg => {
        const isSent = msg.sender_id === currentUser.user_id;
        const bubbleClass = isSent ? 'message-sent' : 'message-received';
        const msgDate = new Date(msg.created_at).toLocaleDateString('ar-SA');
        
        // إضافة تاريخ الفاصل إذا تغير التاريخ
        if (lastDate !== msgDate) {
            html += `
                <div class="date-separator">
                    <span>${msgDate}</span>
                </div>
            `;
            lastDate = msgDate;
        }
        
        const time = new Date(msg.created_at).toLocaleTimeString('ar-SA', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        html += `
            <div class="message-bubble ${bubbleClass}">
                <div class="message-content">${msg.content}</div>
                <div class="message-time">
                    ${time}
                    ${isSent ? '' : ` | من: ${msg.sender.full_name}`}
                    ${isSent ? '<i class="fas fa-check"></i>' : ''}
                </div>
            </div>
        `;
    });
    
    messagesArea.innerHTML = html;
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

// تحديث الرسائل كمقروءة
async function markMessagesAsRead(userId) {
    try {
        const currentUser = window.AppState.currentUser;
        if (!currentUser) return;
        
        const { error } = await window.EduPath.supabase
            .from('messages')
            .update({ is_read: true })
            .eq('receiver_id', currentUser.user_id)
            .eq('sender_id', userId)
            .eq('is_read', false);

        if (error) throw error;
        
        // تحديث العداد
        await window.Helpers.fetchNotifications();
        
    } catch (error) {
        console.error('Error marking messages as read:', error);
    }
}

// عرض خطأ في المحادثة
function showConversationError() {
    const messagesArea = document.getElementById('messagesArea');
    if (messagesArea) {
        messagesArea.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>حدث خطأ في تحميل المحادثة</p>
                <button class="btn btn-outline btn-sm" onclick="loadConversation(PageState.selectedTeacher)">
                    <i class="fas fa-redo"></i> إعادة المحاولة
                </button>
            </div>
        `;
    }
}

// إرسال رسالة
async function sendMessage() {
    if (!PageState.selectedTeacher) {
        window.Helpers.showToast('الرجاء اختيار محادثة أولاً', 'warning');
        return;
    }
    
    const messageText = document.getElementById('messageText').value.trim();
    if (!messageText) {
        window.Helpers.showToast('الرجاء كتابة رسالة', 'warning');
        return;
    }
    
    try {
        const { data, error } = await window.EduPath.supabase
            .from('messages')
            .insert([{
                sender_id: window.AppState.currentUser.user_id,
                receiver_id: PageState.selectedTeacher,
                content: messageText,
                is_read: false
            }]);
        
        if (error) throw error;
        
        // إعادة تحميل المحادثة
        await loadConversation(PageState.selectedTeacher);
        
        // إعادة تحميل قائمة الرسائل
        await loadMessages();
        
        // مسح حقل النص
        document.getElementById('messageText').value = '';
        
        window.Helpers.showToast('تم إرسال الرسالة', 'success');
        
    } catch (error) {
        console.error('Error sending message:', error);
        window.Helpers.showToast('حدث خطأ في إرسال الرسالة', 'error');
    }
}

// تبديل علامات التبويب
function switchTab(tabName) {
    // تحديث أزرار التبويب
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // إضافة active للزر المحدد
    const activeBtn = document.querySelector(`.tab-btn[onclick*="${tabName}"]`);
    if (activeBtn) {
        activeBtn.classList.add('active');
    }
    
    // إخفاء جميع المحتويات
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // إظهار المحتوى المحدد
    const tabContent = document.getElementById(`${tabName}-tab`);
    if (tabContent) {
        tabContent.classList.add('active');
    }
    
    PageState.currentTab = tabName;
    
    // تحميل البيانات إذا لزم الأمر
    if (tabName === 'grades' && PageState.academicYears.length === 0) {
        loadAcademicYears();
    }
}

// فتح نافذة رسالة جديدة
function startNewMessage() {
    const modal = document.getElementById('newMessageModal');
    if (modal) {
        modal.style.display = 'flex';
        document.getElementById('teacherSelector').focus();
    }
}

// إغلاق نافذة رسالة جديدة
function closeNewMessageModal() {
    const modal = document.getElementById('newMessageModal');
    if (modal) {
        modal.style.display = 'none';
        // إعادة تعيين الحقول
        document.getElementById('teacherSelector').value = '';
        document.getElementById('messageSubject').value = '';
        document.getElementById('newMessageText').value = '';
    }
}

// إرسال رسالة جديدة
async function sendNewMessage() {
    const teacherId = document.getElementById('teacherSelector').value;
    const subject = document.getElementById('messageSubject').value.trim();
    const message = document.getElementById('newMessageText').value.trim();
    
    if (!teacherId) {
        window.Helpers.showToast('الرجاء اختيار معلم', 'warning');
        return;
    }
    
    if (!message) {
        window.Helpers.showToast('الرجاء كتابة رسالة', 'warning');
        return;
    }
    
    try {
        const fullMessage = subject ? `[${subject}] ${message}` : message;
        
        const { data, error } = await window.EduPath.supabase
            .from('messages')
            .insert([{
                sender_id: window.AppState.currentUser.user_id,
                receiver_id: teacherId,
                content: fullMessage,
                is_read: false
            }]);
        
        if (error) throw error;
        
        // إغلاق النافذة
        closeNewMessageModal();
        
        // تحميل الرسائل من جديد
        await loadMessages();
        
        // فتح المحادثة الجديدة
        const teacher = PageState.teachers.find(t => t.id === teacherId);
        if (teacher) {
            await openConversation(teacherId, teacher.full_name);
        }
        
        window.Helpers.showToast('تم إرسال الرسالة', 'success');
        
    } catch (error) {
        console.error('Error sending new message:', error);
        window.Helpers.showToast('حدث خطأ في إرسال الرسالة', 'error');
    }
}

// تهيئة علامات التبويب
function initTabs() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.getAttribute('onclick').match(/'(\w+)'/)[1];
            switchTab(tabId);
        });
    });
}

// تحديث الإشعارات
async function updateNotifications() {
    const badge = document.querySelector('.notification-badge');
    if (badge && window.AppState.notifications) {
        const unreadCount = window.AppState.notifications.filter(n => !n.is_read).length;
        badge.textContent = unreadCount;
        badge.style.display = unreadCount > 0 ? 'flex' : 'none';
    }
}

// تصدير الدوال للاستخدام العام
window.ParentStudentDashboard = {
    switchTab,
    startNewMessage,
    closeNewMessageModal,
    sendNewMessage,
    sendMessage,
    updateNotifications,
    loadContentFeed,
    loadGradesForYear,
    loadMessages
};