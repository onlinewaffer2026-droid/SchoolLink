// تحميل قائمة المدارس
async function loadSchools() {
    try {
        const schoolsList = document.getElementById('schoolsList');
        schoolsList.innerHTML = `
            <div class="card text-center" style="grid-column: 1 / -1;">
                <i class="fas fa-spinner fa-spin fa-2x"></i>
                <p>جاري تحميل المدارس...</p>
            </div>
        `;

        const { data: schools, error } = await window.EduPath.supabase
            .from('schools')
            .select(`
                *,
                academic_years (*),
                users (role)
            `)
            .order('created_at', { ascending: false });

        if (error) throw error;

        SuperState.schools = schools;
        displaySchools(0);
        setupPagination();

    } catch (error) {
        console.error('Error loading schools:', error);
        window.Helpers.showToast('فشل في تحميل المدارس', 'error');
        
        document.getElementById('schoolsList').innerHTML = `
            <div class="card text-center" style="grid-column: 1 / -1;">
                <i class="fas fa-exclamation-triangle fa-2x text-danger"></i>
                <p>حدث خطأ في تحميل البيانات</p>
                <button class="btn btn-outline" onclick="loadSchools()">
                    <i class="fas fa-redo"></i>
                    إعادة المحاولة
                </button>
            </div>
        `;
        
        // إعادة رمي الخطأ ليتم التقاطه في loadInitialData وعدم عرض رسالة "تم بنجاح"
        throw error;
    }
}

// عرض المدارس
function displaySchools(pageIndex) {
    const schoolsList = document.getElementById('schoolsList');
    const startIndex = pageIndex * SuperState.itemsPerPage;
    const endIndex = startIndex + SuperState.itemsPerPage;
    const currentSchools = SuperState.schools.slice(startIndex, endIndex);

    if (currentSchools.length === 0) {
        schoolsList.innerHTML = `
            <div class="card text-center" style="grid-column: 1 / -1;">
                <i class="fas fa-school fa-2x text-muted"></i>
                <h3>لا توجد مدارس</h3>
                <p>لم يتم إضافة أي مدارس بعد. يمكنك إضافة مدرسة جديدة من خلال النموذج أعلاه.</p>
            </div>
        `;
        return;
    }

    schoolsList.innerHTML = currentSchools.map(school => `
        <div class="card school-card">
            <div class="school-header">
                <div class="school-icon">
                    <i class="fas fa-school"></i>
                </div>
                <div class="school-info">
                    <h3 class="school-name">${school.name}</h3>
                    <p class="school-date">
                        <i class="far fa-calendar"></i>
                        ${window.Helpers.formatDate(school.created_at)}
                    </p>
                </div>
                <div class="school-actions">
                    <button class="btn btn-icon" onclick="viewSchoolDetails('${school.id}')" title="عرض التفاصيل">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            <div class="school-stats">
                <div class="stat-item">
                    <i class="fas fa-calendar-alt"></i>
                    <div>
                        <span class="stat-label">السنوات الدراسية</span>
                        <span class="stat-value">${school.academic_years?.length || 0}</span>
                    </div>
                </div>
                <div class="stat-item">
                    <i class="fas fa-user-tie"></i>
                    <div>
                        <span class="stat-label">المديرون</span>
                        <span class="stat-value">1</span>
                    </div>
                </div>
            </div>
            <div class="school-footer">
                <span class="badge ${school.academic_years?.some(y => y.is_active) ? 'badge-success' : 'badge-warning'}">
                    ${school.academic_years?.some(y => y.is_active) ? 'نشطة' : 'غير نشطة'}
                </span>
                <button class="btn btn-sm btn-outline" onclick="viewSchoolDetails('${school.id}')">
                    <i class="fas fa-info-circle"></i>
                    التفاصيل
                </button>
            </div>
        </div>
    `).join('');
}

// إعداد الترقيم الصفحي
function setupPagination() {
    const pagination = document.getElementById('schoolsPagination');
    const totalPages = Math.ceil(SuperState.schools.length / SuperState.itemsPerPage);

    if (totalPages <= 1) {
        pagination.innerHTML = '';
        return;
    }

    let paginationHTML = `
        <button class="pagination-btn ${SuperState.currentPageIndex === 0 ? 'disabled' : ''}" 
                onclick="changePage(${SuperState.currentPageIndex - 1})">
            <i class="fas fa-chevron-right"></i>
        </button>
    `;

    for (let i = 0; i < totalPages; i++) {
        paginationHTML += `
            <button class="pagination-btn ${SuperState.currentPageIndex === i ? 'active' : ''}" 
                    onclick="changePage(${i})">
                ${i + 1}
            </button>
        `;
    }

    paginationHTML += `
        <button class="pagination-btn ${SuperState.currentPageIndex === totalPages - 1 ? 'disabled' : ''}" 
                onclick="changePage(${SuperState.currentPageIndex + 1})">
            <i class="fas fa-chevron-left"></i>
        </button>
    `;

    pagination.innerHTML = paginationHTML;
}

// تغيير الصفحة
function changePage(newPageIndex) {
    const totalPages = Math.ceil(SuperState.schools.length / SuperState.itemsPerPage);
    
    if (newPageIndex >= 0 && newPageIndex < totalPages) {
        SuperState.currentPageIndex = newPageIndex;
        displaySchools(newPageIndex);
        setupPagination();
    }
}

// تصفية المدارس
function filterSchools() {
    const searchTerm = document.getElementById('schoolSearch').value.toLowerCase();
    
    if (!searchTerm) {
        displaySchools(SuperState.currentPageIndex);
        setupPagination();
        return;
    }

    const filteredSchools = SuperState.schools.filter(school =>
        school.name.toLowerCase().includes(searchTerm)
    );

    const schoolsList = document.getElementById('schoolsList');
    
    if (filteredSchools.length === 0) {
        schoolsList.innerHTML = `
            <div class="card text-center" style="grid-column: 1 / -1;">
                <i class="fas fa-search fa-2x text-muted"></i>
                <h3>لا توجد نتائج</h3>
                <p>لم يتم العثور على مدارس تطابق "${searchTerm}"</p>
            </div>
        `;
        document.getElementById('schoolsPagination').innerHTML = '';
        return;
    }

    schoolsList.innerHTML = filteredSchools.map(school => `
        <div class="card school-card">
            <div class="school-header">
                <div class="school-icon">
                    <i class="fas fa-school"></i>
                </div>
                <div class="school-info">
                    <h3 class="school-name">${school.name}</h3>
                    <p class="school-date">
                        <i class="far fa-calendar"></i>
                        ${window.Helpers.formatDate(school.created_at)}
                    </p>
                </div>
            </div>
            <div class="school-footer">
                <button class="btn btn-sm btn-outline" onclick="viewSchoolDetails('${school.id}')">
                    <i class="fas fa-info-circle"></i>
                    التفاصيل
                </button>
            </div>
        </div>
    `).join('');
}

// 1. عرض تفاصيل المدرسة
async function viewSchoolDetails(schoolId) {
    try {
        const { data: school, error } = await window.EduPath.supabase
            .from('schools')
            .select(`
                *,
                academic_years (*),
                users (*)
            `)
            .eq('id', schoolId)
            .single();

        if (error) throw error;

        SuperState.currentSchoolDetails = school;

        document.getElementById('modalSchoolName').textContent = school.name;
        
        // البحث عن المدير
        const admin = school.users.find(u => u.role === 'admin');
        const activeYear = school.academic_years.find(y => y.is_active);
        
        // إحصائيات المستخدمين
        const adminCount = school.users.filter(u => u.role === 'admin').length;
        const teacherCount = school.users.filter(u => u.role === 'teacher').length;
        const studentCount = school.users.filter(u => u.role === 'student').length;

        // تحديد نص ولون زر التعطيل بناءً على الحالة الحالية
        const statusBtnText = school.is_active ? 'تعطيل المدرسة' : 'تنشيط المدرسة';
        const statusBtnClass = school.is_active ? 'btn-danger' : 'btn-success';
        const statusIcon = school.is_active ? 'fa-ban' : 'fa-check-circle';

        document.getElementById('schoolDetailsContent').innerHTML = `
            <div class="detail-section">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h4><i class="fas fa-info-circle"></i> المعلومات الأساسية</h4>
                    <span class="badge ${school.is_active ? 'badge-success' : 'badge-danger'}">
                        ${school.is_active ? 'نشطة' : 'معطلة'}
                    </span>
                </div>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="detail-label">اسم المدرسة:</span>
                        <span class="detail-value">${school.name}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">تاريخ الإنشاء:</span>
                        <span class="detail-value">${window.Helpers.formatDate(school.created_at)}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">عدد السنوات الدراسية:</span>
                        <span class="detail-value">${school.academic_years?.length || 0}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">العام الدراسي النشط:</span>
                        <span class="detail-value">${activeYear ? activeYear.name : 'لا يوجد'}</span>
                    </div>
                </div>
            </div>

            <!-- قسم معلومات المدير -->
            <div class="detail-section">
                <h4><i class="fas fa-user-tie"></i> معلومات المدير</h4>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="detail-label">اسم المدير:</span>
                        <span class="detail-value">${admin ? admin.full_name : 'غير محدد'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">كود دخول المدير:</span>
                        <span class="detail-value code-value">${admin ? admin.login_code : 'غير محدد'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">تاريخ إنشاء الحساب:</span>
                        <span class="detail-value">${admin ? window.Helpers.formatDate(admin.created_at) : 'غير محدد'}</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">حالة الحساب:</span>
                        <span class="detail-value">
                            <span class="badge ${admin ? 'badge-success' : 'badge-warning'}">
                                ${admin ? 'نشط' : 'غير موجود'}
                            </span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- قسم الإحصائيات -->
            <div class="detail-section">
                <h4><i class="fas fa-chart-bar"></i> إحصائيات المدرسة</h4>
                <div class="stats-grid">
                    <div class="stat-card mini">
                        <i class="fas fa-user-tie"></i>
                        <div>
                            <div class="stat-value">${adminCount}</div>
                            <div class="stat-label">مدير</div>
                        </div>
                    </div>
                    <div class="stat-card mini">
                        <i class="fas fa-chalkboard-teacher"></i>
                        <div>
                            <div class="stat-value">${teacherCount}</div>
                            <div class="stat-label">معلم</div>
                        </div>
                    </div>
                    <div class="stat-card mini">
                        <i class="fas fa-user-graduate"></i>
                        <div>
                            <div class="stat-value">${studentCount}</div>
                            <div class="stat-label">طالب</div>
                        </div>
                    </div>
                    <div class="stat-card mini">
                        <i class="fas fa-calendar-alt"></i>
                        <div>
                            <div class="stat-value">${school.academic_years?.length || 0}</div>
                            <div class="stat-label">عام دراسي</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- قسم السنوات الدراسية -->
            <div class="detail-section">
                <h4><i class="fas fa-calendar-alt"></i> السنوات الدراسية</h4>
                <div class="years-list">
                    ${school.academic_years && school.academic_years.length > 0 ? 
                        school.academic_years.map(year => `
                            <div class="year-item ${year.is_active ? 'active' : ''}">
                                <div class="year-info">
                                    <span class="year-name">${year.name}</span>
                                    <span class="year-status">${year.is_active ? 'نشط' : 'مغلق'}</span>
                                </div>
                                <div class="year-date">${window.Helpers.formatDate(year.created_at)}</div>
                            </div>
                        `).join('') : 
                        '<p class="text-muted text-center">لا توجد سنوات دراسية</p>'
                    }
                </div>
            </div>
        `;

        // تحديث أزرار التحكم في الـ Modal
        const modalFooter = document.querySelector('#schoolDetailsModal .modal-footer');
        modalFooter.innerHTML = `
            <button class="btn btn-outline" onclick="closeModal('schoolDetailsModal')">
                <i class="fas fa-times"></i>
                إغلاق
            </button>
            <button class="btn btn-warning" onclick="openEditModal('${school.id}', '${school.name}')">
                <i class="fas fa-edit"></i>
                تعديل الاسم
            </button>
            <button class="btn ${statusBtnClass}" onclick="toggleSchoolStatus('${school.id}', ${school.is_active})">
                <i class="fas ${statusIcon}"></i>
                ${statusBtnText}
            </button>
        `;

        document.getElementById('schoolDetailsModal').style.display = 'block';

    } catch (error) {
        console.error('Error:', error);
        window.Helpers.showToast('فشل في تحميل التفاصيل', 'error');
    }
}


// إضافة في ملف schools.js بعد دالة viewSchoolDetails
function copyAdminCode(code) {
    navigator.clipboard.writeText(code)
        .then(() => {
            window.Helpers.showToast('تم نسخ الكود إلى الحافظة', 'success');
        })
        .catch(err => {
            console.error('Error copying text: ', err);
            window.Helpers.showToast('فشل في نسخ الكود', 'error');
        });
}

// 2. فتح نافذة التعديل
function openEditModal(id, name) {
    document.getElementById('editSchoolId').value = id;
    document.getElementById('editSchoolNameInput').value = name;
    document.getElementById('editSchoolModal').style.display = 'block';
}

// 3. حفظ الاسم الجديد
async function saveSchoolName() {
    const id = document.getElementById('editSchoolId').value;
    const newName = document.getElementById('editSchoolNameInput').value.trim();

    if (!newName) return window.Helpers.showToast('يرجى إدخال اسم صحيح', 'error');

    try {
        const { error } = await window.EduPath.supabase
            .from('schools')
            .update({ name: newName })
            .eq('id', id);

        if (error) throw error;

        window.Helpers.showToast('تم تحديث اسم المدرسة بنجاح', 'success');
        closeModal('editSchoolModal');
        closeModal('schoolDetailsModal');
        loadSchools(); // إعادة تحميل القائمة
    } catch (error) {
        window.Helpers.showToast('حدث خطأ أثناء التحديث', 'error');
    }
}

// 4. تعطيل أو تفعيل المدرسة
async function toggleSchoolStatus(id, currentStatus) {
    const action = currentStatus ? 'تعطيل' : 'تنشيط';
    if (!confirm(`هل أنت متأكد من ${action} هذه المدرسة؟ ${currentStatus ? 'لن يتمكن مستخدموها من الدخول.' : ''}`)) return;

    try {
        const { error } = await window.EduPath.supabase
            .from('schools')
            .update({ is_active: !currentStatus })
            .eq('id', id);

        if (error) throw error;

        window.Helpers.showToast(`تم ${action} المدرسة بنجاح`, 'success');
        closeModal('schoolDetailsModal');
        loadSchools();
    } catch (error) {
        window.Helpers.showToast('حدث خطأ أثناء تغيير الحالة', 'error');
    }
}

// توليد كود المدير
function generateAdminCode() {
    const code = 'ADM' + window.Helpers.generateLoginCode(5);
    document.getElementById('adminLoginCode').value = code;
}

// إعادة تعيين النموذج
function resetForm() {
    document.getElementById('addSchoolForm').reset();
    generateAdminCode();
    document.getElementById('academicYearName').value = '2024-2025';
}

// إرسال نموذج إضافة مدرسة
document.getElementById('addSchoolForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const schoolName = document.getElementById('schoolName').value.trim();
    const academicYearName = document.getElementById('academicYearName').value.trim();
    const adminName = document.getElementById('adminName').value.trim();
    const adminLoginCode = document.getElementById('adminLoginCode').value.trim();

    // التحقق من البيانات
    if (!schoolName || !academicYearName || !adminName || !adminLoginCode) {
        window.Helpers.showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
        return;
    }

    try {
        // إظهار مؤشر التحميل
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإنشاء...';
        submitBtn.disabled = true;

        // استدعاء دالة RPC لإنشاء المدرسة
        const { data, error } = await window.EduPath.supabase.rpc(
            'create_school_with_admin',
            {
                school_name: schoolName,
                academic_year_name: academicYearName,
                admin_name: adminName,
                admin_login_code: adminLoginCode
            }
        );

        if (error) throw error;

        window.Helpers.showToast('تم إنشاء المدرسة بنجاح', 'success');
        
        // إعادة تعيين النموذج
        resetForm();
        
        // تحديث قائمة المدارس
        await loadSchools();
        await updateDashboardStats();

    } catch (error) {
        console.error('Error creating school:', error);
        window.Helpers.showToast(`فشل في إنشاء المدرسة: ${error.message}`, 'error');
    } finally {
        // استعادة حالة الزر
        const submitBtn = document.querySelector('#addSchoolForm button[type="submit"]');
        submitBtn.innerHTML = '<i class="fas fa-save"></i> إنشاء المدرسة';
        submitBtn.disabled = false;
    }
});

// تحديث قائمة المدارس
function refreshSchoolsList() {
    loadSchools();
    window.Helpers.showToast('جاري تحديث قائمة المدارس...', 'info');
}

// تصدير بيانات المدارس
function exportSchoolsData() {
    if (!SuperState.schools.length) return window.Helpers.showToast('لا توجد بيانات', 'warning');

    const dataRows = SuperState.schools.map(s => ({
        'اسم المدرسة': s.name.replace(/,/g, '-'),
        'الحالة': s.is_active ? 'نشطة' : 'معطلة'
    }));

    const headers = Object.keys(dataRows[0]).join(',');
    const rows = dataRows.map(r => Object.values(r).join(',')).join('\n');
    const csvContent = headers + '\n' + rows;

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'تقرير_المدارس.csv';
    document.body.appendChild(link); // مهم للموبايل
    link.click();
    document.body.removeChild(link);
}

// دالة تحويل البيانات إلى نص CSV
function convertToCSV(data) {
    const headers = Object.keys(data[0]);
    
    // إنشاء سطر العناوين
    const headerRow = headers.join(',');
    
    // إنشاء سطور البيانات
    const dataRows = data.map(row => {
        return headers.map(header => {
            let cellValue = row[header] === null || row[header] === undefined ? '' : row[header];
            // إضافة علامات اقتباس للقيم التي تحتوي على فاصلة لمنع تداخل الأعمدة
            if (cellValue.toString().includes(',')) {
                cellValue = `"${cellValue}"`;
            }
            return cellValue;
        }).join(',');
    });
    
    return [headerRow, ...dataRows].join('\n');
}

// دالة تفعيل تحميل الملف في المتصفح مع دعم اللغة العربية (BOM)
function downloadCSV(csv, filename) {
    // إضافة \uFEFF وهي "Byte Order Mark" ليفهم Excel أن الملف بترميز UTF-8 (يدعم العربي)
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}