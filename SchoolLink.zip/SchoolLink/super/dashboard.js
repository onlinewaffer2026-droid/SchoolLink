// حالة الصفحة
const SuperState = {
    currentPage: 'dashboard',
    schools: [],
    currentPageIndex: 0,
    itemsPerPage: 6,
    charts: {},
    currentSchoolDetails: null
};

// تهيئة الصفحة
document.addEventListener('DOMContentLoaded', async function() {
    // التحقق من صلاحية المستخدم
    if (!window.AppState || !window.AppState.currentUser || window.AppState.currentUser.role !== 'super') {
        window.Helpers.showToast('ليس لديك صلاحية الوصول إلى هذه الصفحة', 'error');
        setTimeout(() => {
            window.location.href = '../index.html';
        }, 2000);
        return;
    }

    // تحديث اسم المستخدم
    document.getElementById('currentUserName').textContent = window.AppState.currentUser.full_name;

    // تهيئة التنقل
    initializeNavigation();

    // تحميل البيانات الأولية
    await loadInitialData();

    // تهيئة الرسوم البيانية
    initializeCharts();

    // تفعيل Realtime للتنبيهات
    setupRealtime();

    // توليد كود المدير تلقائياً
    generateAdminCode();
});

// 1. الدالة الموحدة للتنقل بين الأقسام
function navigateToSection(sectionId) {
    // تحديث روابط القائمة العلوية
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${sectionId}`) link.classList.add('active');
    });

    // إخفاء الأقسام وإظهار القسم المطلوب
    document.querySelectorAll('.section').forEach(section => section.classList.remove('active-section'));
    
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active-section');
        SuperState.currentPage = sectionId;

        // تنفيذ الجلب التلقائي للبيانات حسب القسم المفتوح
        switch (sectionId) {
            case 'dashboard': updateDashboardStats(); break;
            case 'schools': loadSchools(); break;
            case 'studentsReportSection': loadGlobalUsers('student', 'studentsReportBody'); break;
            case 'teachersReportSection': loadGlobalUsers('teacher', 'teachersReportBody'); break;
            case 'academicYearsSection': loadAllAcademicYears(); break;
            case 'statistics': updateStatistics(); break;
        }
        
        // إغلاق القائمة في الموبايل
        const navLinksContainer = document.querySelector('.nav-links');
        if (navLinksContainer) navLinksContainer.classList.remove('show');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// 2. الدالة التي تعمل عند تحميل الصفحة لربط أزرار القائمة العلوية
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // نتحقق أولاً إذا كان الرابط يؤدي لقسم داخلي (يبدأ بـ #)
            const href = this.getAttribute('href');
            if (href && href.startsWith('#')) {
                e.preventDefault();
                const sectionId = href.substring(1);
                navigateToSection(sectionId);
            }
        });
    });
}

// تحميل البيانات الأولية
async function loadInitialData() {
    try {
        // تحميل الإحصائيات
        await updateDashboardStats();
        
        // تحميل المدارس
        await loadSchools();
        
        // تحميل النشاط الأخير
        await loadRecentActivity();
        
        window.Helpers.showToast('تم تحميل البيانات بنجاح', 'success');
    } catch (error) {
        console.error('Error loading initial data:', error);
        window.Helpers.showToast('حدث خطأ في تحميل البيانات', 'error');
    }
}

// تحديث إحصائيات لوحة التحكم
async function updateDashboardStats() {
    try {
        // 1. جلب عدد المدارس
        const { count: schoolsCount, error: schoolsError } = await window.EduPath.supabase
            .from('schools')
            .select('*', { count: 'exact', head: true });
        
        if (!schoolsError) {
            const element = document.getElementById('totalSchools');
            if (element) element.textContent = schoolsCount || 0;
        }

        // 2. جلب عدد المستخدمين
        const { data: usersData, error: usersError } = await window.EduPath.supabase
            .from('users')
            .select('role');
        
        if (!usersError && usersData) {
            const students = usersData.filter(u => u.role === 'student').length;
            const teachers = usersData.filter(u => u.role === 'teacher').length;
            
            const studentEl = document.getElementById('totalStudents');
            const teacherEl = document.getElementById('totalTeachers');
            
            if (studentEl) studentEl.textContent = students;
            if (teacherEl) teacherEl.textContent = teachers;
        }

        // 3. جلب السنوات النشطة
        const { count: yearsCount, error: yearsError } = await window.EduPath.supabase
            .from('academic_years')
            .select('*', { count: 'exact', head: true })
            .eq('is_active', true);
        
        if (!yearsError) {
            const yearEl = document.getElementById('activeYears');
            if (yearEl) yearEl.textContent = yearsCount || 0;
        }

    } catch (error) {
        console.error('Error updating dashboard stats:', error);
    }
}

// تهيئة الرسوم البيانية
function initializeCharts() {
    // تأجيل تهيئة الرسوم البيانية حتى يتم تحميل مكتبة Chart.js
    if (typeof Chart === 'undefined') {
        setTimeout(initializeCharts, 100);
        return;
    }

    // توزيع المستخدمين
    const usersCtx = document.getElementById('usersDistributionChart').getContext('2d');
    SuperState.charts.usersDistribution = new Chart(usersCtx, {
        type: 'doughnut',
        data: {
            labels: ['مديرون', 'معلمون', 'طلاب'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: [
                    'rgba(103, 58, 183, 0.8)',
                    'rgba(33, 150, 243, 0.8)',
                    'rgba(76, 175, 80, 0.8)'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    rtl: true
                }
            }
        }
    });

    // نمو المدارس
    const growthCtx = document.getElementById('schoolsGrowthChart').getContext('2d');
    SuperState.charts.schoolsGrowth = new Chart(growthCtx, {
        type: 'line',
        data: {
            labels: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو'],
            datasets: [{
                label: 'عدد المدارس',
                data: [0, 0, 0, 0, 0, 0],
                borderColor: 'rgba(103, 58, 183, 1)',
                backgroundColor: 'rgba(103, 58, 183, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    rtl: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// تحديث الإحصائيات
async function updateStatistics() {
    try {
        // جلب بيانات المستخدمين
        const { data: users, error: usersError } = await window.EduPath.supabase
            .from('users')
            .select('role');
        
        if (!usersError) {
            const admins = users.filter(u => u.role === 'admin').length;
            const teachers = users.filter(u => u.role === 'teacher').length;
            const students = users.filter(u => u.role === 'student').length;
            
            // تحديث مخطط توزيع المستخدمين
            if (SuperState.charts.usersDistribution) {
                SuperState.charts.usersDistribution.data.datasets[0].data = [admins, teachers, students];
                SuperState.charts.usersDistribution.update();
            }
        }

        // تحديث مخطط نمو المدارس
        if (SuperState.charts.schoolsGrowth) {
            // هذه بيانات تجريبية - يمكن استبدالها ببيانات حقيقية
            const mockData = [2, 3, 4, 6, 8, 10];
            SuperState.charts.schoolsGrowth.data.datasets[0].data = mockData;
            SuperState.charts.schoolsGrowth.update();
        }

        // تحديث إحصائيات السنوات الدراسية
        await updateAcademicYearsStats();

        // تحديث التقرير التفصيلي
        await generateDetailedReport();

    } catch (error) {
        console.error('Error updating statistics:', error);
    }
}

// تحديث إحصائيات السنوات الدراسية
async function updateAcademicYearsStats() {
    try {
        const { data: years, error } = await window.EduPath.supabase
            .from('academic_years')
            .select('*, schools(name)')
            .order('created_at', { ascending: false })
            .limit(5);

        if (error) throw error;

        const statsContainer = document.getElementById('academicYearsStats');
        statsContainer.innerHTML = years.map(year => `
            <div class="stat-item-row">
                <div class="stat-item-info">
                    <i class="fas fa-calendar ${year.is_active ? 'text-success' : 'text-muted'}"></i>
                    <div>
                        <span class="stat-item-title">${year.name}</span>
                        <span class="stat-item-subtitle">${year.schools.name}</span>
                    </div>
                </div>
                <div class="stat-item-value">
                    <span class="badge ${year.is_active ? 'badge-success' : 'badge-secondary'}">
                        ${year.is_active ? 'نشط' : 'مغلق'}
                    </span>
                </div>
            </div>
        `).join('');

    } catch (error) {
        console.error('Error updating academic years stats:', error);
    }
}

// تحميل النشاط الأخير
async function loadRecentActivity() {
    try {
        const { data: activities, error } = await window.EduPath.supabase
            .from('notifications')
            .select('*, users(full_name, role)')
            .order('created_at', { ascending: false })
            .limit(5);

        if (error) throw error;

        const activityContainer = document.getElementById('recentActivity');
        if (!activityContainer) return;

        if (!activities || activities.length === 0) {
            activityContainer.innerHTML = '<p class="text-center">لا يوجد نشاط أخير</p>';
            return;
        }

        activityContainer.innerHTML = activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon">
                    <i class="fas fa-bell ${activity.is_read ? 'text-muted' : 'text-primary'}"></i>
                </div>
                <div class="activity-content">
                    <p class="activity-message">${activity.message}</p>
                    <div class="activity-meta">
                        <span class="activity-user">${activity.users?.full_name || 'مستخدم غير معروف'}</span>
                        <span class="activity-time">${window.Helpers.formatDate(activity.created_at)}</span>
                    </div>
                </div>
            </div>
        `).join('');

    } catch (error) {
        console.error('Error loading recent activity:', error);
        const activityContainer = document.getElementById('recentActivity');
        if (activityContainer) activityContainer.innerHTML = '<p class="text-center">تعذر تحميل النشاط</p>';
    }
}

// توليد التقرير التفصيلي
async function generateDetailedReport() {
    const period = document.getElementById('reportPeriod').value;
    const reportContainer = document.getElementById('detailedReport');

    // عرض مؤشر التحميل
    reportContainer.innerHTML = `
        <div class="text-center">
            <i class="fas fa-spinner fa-spin fa-2x"></i>
            <p>جاري تحضير التقرير...</p>
        </div>
    `;

    try {
        // جلب البيانات حسب الفترة المحددة
        const now = new Date();
        let startDate = new Date();

        switch (period) {
            case 'monthly':
                startDate.setMonth(now.getMonth() - 1);
                break;
            case 'quarterly':
                startDate.setMonth(now.getMonth() - 3);
                break;
            case 'yearly':
                startDate.setFullYear(now.getFullYear() - 1);
                break;
            case 'all':
                startDate = new Date(0); // بداية التاريخ
                break;
        }

        // جلب المدارس المضافة في الفترة المحددة
        const { data: newSchools, error: schoolsError } = await window.EduPath.supabase
            .from('schools')
            .select('*')
            .gte('created_at', startDate.toISOString());

        // جلب المستخدمين الجدد
        const { data: newUsers, error: usersError } = await window.EduPath.supabase
            .from('users')
            .select('*')
            .gte('created_at', startDate.toISOString());

        if (schoolsError || usersError) throw schoolsError || usersError;

        // تحضير التقرير
        const totalSchools = newSchools.length;
        const totalUsers = newUsers.length;
        
        const usersByRole = {
            admin: newUsers.filter(u => u.role === 'admin').length,
            teacher: newUsers.filter(u => u.role === 'teacher').length,
            student: newUsers.filter(u => u.role === 'student').length
        };

        reportContainer.innerHTML = `
            <div class="report-grid">
                <div class="report-card">
                    <h4><i class="fas fa-school"></i> المدارس الجديدة</h4>
                    <div class="report-value">${totalSchools}</div>
                    <p>مدرسة مضافة في الفترة المحددة</p>
                </div>
                
                <div class="report-card">
                    <h4><i class="fas fa-users"></i> المستخدمون الجدد</h4>
                    <div class="report-value">${totalUsers}</div>
                    <p>مستخدم جديد في الفترة المحددة</p>
                </div>
                
                <div class="report-card">
                    <h4><i class="fas fa-user-tie"></i> المديرون</h4>
                    <div class="report-value">${usersByRole.admin}</div>
                    <p>مدير جديد</p>
                </div>
                
                <div class="report-card">
                    <h4><i class="fas fa-chalkboard-teacher"></i> المعلمون</h4>
                    <div class="report-value">${usersByRole.teacher}</div>
                    <p>معلم جديد</p>
                </div>
                
                <div class="report-card">
                    <h4><i class="fas fa-user-graduate"></i> الطلاب</h4>
                    <div class="report-value">${usersByRole.student}</div>
                    <p>طالب جديد</p>
                </div>
                
                <div class="report-card">
                    <h4><i class="fas fa-chart-line"></i> معدل النمو</h4>
                    <div class="report-value">${calculateGrowthRate(totalSchools, period)}%</div>
                    <p>نمو المدارس</p>
                </div>
            </div>
            
            <div class="report-summary">
                <h4><i class="fas fa-file-alt"></i> ملخص التقرير</h4>
                <p>
                    في الفترة المحددة (${getPeriodName(period)})، تم إضافة ${totalSchools} مدارس جديدة 
                    و ${totalUsers} مستخدم جديد إلى النظام. يظهر النظام نمواً إيجابياً بنسبة 
                    ${calculateGrowthRate(totalSchools, period)}% في عدد المدارس.
                </p>
            </div>
        `;

    } catch (error) {
        console.error('Error generating report:', error);
        reportContainer.innerHTML = `
            <div class="text-center text-danger">
                <i class="fas fa-exclamation-triangle fa-2x"></i>
                <p>حدث خطأ في توليد التقرير</p>
            </div>
        `;
    }
}

// حساب معدل النمو
function calculateGrowthRate(currentCount, period) {
    // هذه بيانات تجريبية - يمكن استبدالها ببيانات حقيقية
    const baseRates = {
        monthly: 25,
        quarterly: 40,
        yearly: 75,
        all: 100
    };
    return baseRates[period] || 0;
}

// الحصول على اسم الفترة
function getPeriodName(period) {
    const names = {
        monthly: 'آخر شهر',
        quarterly: 'آخر 3 أشهر',
        yearly: 'آخر سنة',
        all: 'جميع الفترات'
    };
    return names[period] || period;
}

// إغلاق النافذة المنبثقة
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// تفعيل Realtime
function setupRealtime() {
    // الاشتراك في تحديثات المدارس
    const schoolsChannel = window.EduPath.supabase.channel('super_schools_channel')
        .on('postgres_changes', 
            { 
                event: 'INSERT', 
                schema: 'public', 
                table: 'schools' 
            }, 
            payload => {
                window.Helpers.showToast('تمت إضافة مدرسة جديدة', 'info');
                loadSchools();
                updateDashboardStats();
            }
        )
        .on('postgres_changes',
            {
                event: 'DELETE',
                schema: 'public',
                table: 'schools'
            },
            payload => {
                window.Helpers.showToast('تم حذف مدرسة', 'warning');
                loadSchools();
                updateDashboardStats();
            }
        )
        .subscribe();

    // الاشتراك في تحديثات المستخدمين
    const usersChannel = window.EduPath.supabase.channel('super_users_channel')
        .on('postgres_changes',
            {
                event: 'INSERT',
                schema: 'public',
                table: 'users'
            },
            payload => {
                updateDashboardStats();
                updateStatistics();
            }
        )
        .subscribe();
}

// دالة جلب المستخدمين (طلاب أو معلمين) لكل المدارس
async function loadGlobalUsers(role, tableBodyId) {
    const tbody = document.getElementById(tableBodyId);
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center">جاري تحميل البيانات...</td></tr>';

    try {
        const { data, error } = await window.EduPath.supabase
            .from('users')
            .select(`
                full_name,
                subject,
                created_at,
                schools ( name )
            `)
            .eq('role', role)
            .order('created_at', { ascending: false });

        if (error) throw error;

        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center">لا يوجد بيانات حالياً</td></tr>';
            return;
        }

        tbody.innerHTML = data.map(user => `
            <tr>
                <td>${user.full_name}</td>
                <td>${user.schools ? user.schools.name : 'بدون مدرسة'}</td>
                ${role === 'teacher' ? `<td>${user.subject || 'غير محدد'}</td>` : ''}
                <td>${window.Helpers.formatDate(user.created_at)}</td>
            </tr>
        `).join('');

    } catch (error) {
        console.error('Error:', error);
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:red">حدث خطأ أثناء جلب البيانات</td></tr>';
    }
}

// 1. جلب كافة السنوات الدراسية لجميع المدارس
async function loadAllAcademicYears() {
    const tbody = document.getElementById('globalYearsTableBody');
    if (!tbody) return;
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center">جاري جلب البيانات...</td></tr>';

    try {
        const { data, error } = await window.EduPath.supabase
            .from('academic_years')
            .select('id, name, is_active, created_at, schools ( name )')
            .order('created_at', { ascending: false });

        if (error) throw error;

        tbody.innerHTML = data.map(item => {
            // حل مشكلة "المدرسة لا تظهر" بالتحقق من نوع البيانات (مصفوفة أو كائن)
            const schoolName = item.schools ? (Array.isArray(item.schools) ? item.schools[0]?.name : item.schools.name) : 'مدرسة غير معروفة';
            
            return `
                <tr>
                    <td><strong>${schoolName}</strong></td>
                    <td>${item.name}</td>
                    <td><span class="badge ${item.is_active ? 'badge-success' : 'badge-danger'}">${item.is_active ? 'نشط' : 'مغلق'}</span></td>
                    <td>${window.Helpers.formatDate(item.created_at)}</td>
                    <td><button class="btn btn-sm ${item.is_active ? 'btn-outline' : 'btn-primary'}" onclick="toggleYearGlobalStatus('${item.id}', ${item.is_active})">${item.is_active ? 'إغلاق' : 'تنشيط'}</button></td>
                </tr>`;
        }).join('');
    } catch (e) { tbody.innerHTML = '<tr><td colspan="5">خطأ في جلب البيانات</td></tr>'; }
}

// 2. تغيير حالة العام الدراسي (تنشيط/تعطيل)
async function toggleYearGlobalStatus(yearId, currentStatus) {
    const action = currentStatus ? 'إغلاق' : 'تنشيط';
    if (!confirm(`هل أنت متأكد من ${action} هذا العام الدراسي؟`)) return;

    try {
        const { error } = await window.EduPath.supabase
            .from('academic_years')
            .update({ is_active: !currentStatus })
            .eq('id', yearId);

        if (error) throw error;

        window.Helpers.showToast(`تم ${action} العام الدراسي بنجاح`, 'success');
        
        // تحديث البيانات في الصفحة
        loadAllAcademicYears();
        updateDashboardStats(); // لتحديث الرقم الموجود في البطاقة الرئيسية

    } catch (error) {
        console.error('Error:', error);
        window.Helpers.showToast('فشل في تغيير حالة العام الدراسي', 'error');
    }
}

// تبديل قائمة الجوال
function toggleMobileMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('show');
}

// إغلاق القائمة عند النقر خارجها
document.addEventListener('click', function(event) {
    const navLinks = document.querySelector('.nav-links');
    const navbarToggle = document.querySelector('.navbar-toggle');
    
    if (navLinks.classList.contains('show') && 
        !navLinks.contains(event.target) && 
        !navbarToggle.contains(event.target)) {
        navLinks.classList.remove('show');
    }
});

// إغلاق القائمة عند تغيير القسم
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function() {
        const navLinks = document.querySelector('.nav-links');
        if (navLinks.classList.contains('show')) {
            navLinks.classList.remove('show');
        }
    });
});