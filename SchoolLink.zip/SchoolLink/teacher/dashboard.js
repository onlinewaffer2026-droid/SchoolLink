// حالة الصفحة
const TeacherState = {
    currentSection: 'dashboard',
    currentContentTab: 'upload',
    currentClass: null,
    classes: [],
    students: [],
    content: [],
    selectedFiles: [],
    currentConversation: null,
    gradingData: {
        classId: null,
        assignment: '',
        grades: {},
        autoSaveTimer: null
    },
    charts: {}
};

// تهيئة الصفحة
document.addEventListener('DOMContentLoaded', async function() {
    // التحقق من صلاحية المستخدم
    if (!window.AppState.currentUser || window.AppState.currentUser.role !== 'teacher') {
        window.Helpers.showToast('ليس لديك صلاحية الوصول إلى هذه الصفحة', 'error');
        setTimeout(() => {
            window.location.href = '../index.html';
        }, 2000);
        return;
    }

    // تحديث اسم المستخدم
    document.getElementById('currentUserName').textContent = window.AppState.currentUser.full_name;
    document.getElementById('teacherName').textContent = window.AppState.currentUser.full_name;
    document.getElementById('teacherSubject').textContent = window.AppState.currentUser.subject || 'غير محدد';
    document.getElementById('contentSubject').value = window.AppState.currentUser.subject || 'غير محدد';

    // تهيئة التنقل
    initializeNavigation();

    // تحميل البيانات الأولية
    await loadInitialData();

    // تفعيل Realtime للتنبيهات والرسائل
    setupRealtime();

    // تهيئة التحكم بالملفات
    initializeFileUpload();

    // تهيئة الرسوم البيانية
    initializeCharts();
});

// تهيئة التنقل
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // إزالة النشاط من جميع الروابط
            navLinks.forEach(l => l.classList.remove('active'));
            
            // إضافة النشاط للرابط الحالي
            this.classList.add('active');
            
            // إخفاء جميع الأقسام
            document.querySelectorAll('.section').forEach(section => {
                section.classList.remove('active-section');
            });
            
            // إظهار القسم المحدد
            const targetId = this.getAttribute('href').substring(1);
            loadSection(targetId);
            
            // تحديث حالة القسم الحالي
            TeacherState.currentSection = targetId;
        });
    });
}

// تحميل قسم معين
async function loadSection(sectionId) {
    const containerId = `${sectionId}-section-container`;
    let container = document.getElementById(containerId);
    
    // إذا كان القسم هو dashboard، فهو موجود بالفعل في الصفحة
    if (sectionId === 'dashboard') {
        document.getElementById('dashboard').classList.add('active-section');
        return;
    }
    
    // إذا كان الحاوية غير موجودة، أنشئها
    if (!container) {
        container = document.createElement('div');
        container.id = containerId;
        container.className = 'section';
        document.body.appendChild(container);
    }
    
    // إخفاء جميع الحاويات الأخرى
    document.querySelectorAll('.section').forEach(section => {
        if (section.id !== 'dashboard') {
            section.classList.remove('active-section');
        }
    });
    
    // إخفاء dashboard
    document.getElementById('dashboard').classList.remove('active-section');
    
    // تحميل المحتوى حسب القسم
    try {
        switch(sectionId) {
            case 'content':
                await loadContentSection(container);
                break;
            case 'grades':
                await loadGradesSection(container);
                break;
            case 'messages':
                await loadMessagesSection(container);
                break;
            default:
                throw new Error('قسم غير معروف');
        }
        
        container.classList.add('active-section');
    } catch (error) {
        console.error('Error loading section:', error);
        window.Helpers.showToast('حدث خطأ في تحميل القسم', 'error');
    }
}

// التبديل بين الأقسام
function switchToSection(sectionId) {
    const link = document.querySelector(`a[href="#${sectionId}"]`);
    if (link) {
        link.click();
    }
}

// تحميل البيانات الأولية
async function loadInitialData() {
    try {
        // تحميل بيانات المعلم
        await loadTeacherData();
        
        // تحميل الصفوف
        await loadClasses();
        
        // تحميل المحتوى الحديث
        await loadRecentContent();
        
        // تحديث الإحصائيات
        await updateStatistics();
        
        window.Helpers.showToast('تم تحميل البيانات بنجاح', 'success');

    } catch (error) {
        console.error('Error loading initial data:', error);
        window.Helpers.showToast('حدث خطأ في تحميل البيانات', 'error');
    }
}

// تحميل بيانات المعلم
async function loadTeacherData() {
    try {
        const teacherId = window.AppState.currentUser.user_id;
        
        // تحميل بيانات المعلم الكاملة
        const { data: teacher, error } = await window.EduPath.supabase
            .from('users')
            .select(`
                *,
                classes!left (
                    id,
                    name
                )
            `)
            .eq('id', teacherId)
            .single();

        if (error) throw error;

        // تحديث معلومات الصف الحالي
        if (teacher.current_class_id && teacher.classes) {
            TeacherState.currentClass = teacher.classes;
            document.getElementById('currentClassName').textContent = teacher.classes.name;
            
            // تحميل طلاب الصف
            await loadClassStudents(teacher.current_class_id);
        }

    } catch (error) {
        console.error('Error loading teacher data:', error);
    }
}

// تحميل الصفوف
async function loadClasses() {
    try {
        const schoolId = window.AppState.currentUser.school_id;
        
        const { data: classes, error } = await window.EduPath.supabase
            .from('classes')
            .select('*')
            .eq('school_id', schoolId)
            .order('name');

        if (error) throw error;

        TeacherState.classes = classes || [];
        
        // تحديث قوائم الصفوف المنسدلة
        updateClassSelects();

    } catch (error) {
        console.error('Error loading classes:', error);
        window.Helpers.showToast('خطأ في تحميل الصفوف', 'error');
    }
}

// تحديث قوائم الصفوف المنسدلة
function updateClassSelects() {
    const classSelects = [
        'contentClass', 'gradeClassSelect', 'historyClassFilter',
        'performanceClass', 'lessonFilter', 'homeworkFilter'
    ];
    
    classSelects.forEach(selectId => {
        const select = document.getElementById(selectId);
        if (select) {
            // مسح الخيارات الحالية (مع الاحتفاظ بالخيار الأول)
            while (select.options.length > 1) {
                select.remove(1);
            }
            
            // إضافة خيارات الصفوف
            TeacherState.classes.forEach(cls => {
                const option = document.createElement('option');
                option.value = cls.id;
                option.textContent = cls.name;
                select.appendChild(option);
            });
        }
    });

    // إذا كان المعلم لديه صف حالي، ضبطه كقيمة افتراضية
    if (TeacherState.currentClass) {
        const contentClass = document.getElementById('contentClass');
        const gradeClassSelect = document.getElementById('gradeClassSelect');
        
        if (contentClass) contentClass.value = TeacherState.currentClass.id;
        if (gradeClassSelect) gradeClassSelect.value = TeacherState.currentClass.id;
    }
}

// تحميل طلاب الصف
async function loadClassStudents(classId) {
    try {
        const { data: students, error } = await window.EduPath.supabase
            .from('users')
            .select('*')
            .eq('current_class_id', classId)
            .eq('role', 'student')
            .order('full_name');

        if (error) throw error;

        TeacherState.students = students || [];
        document.getElementById('studentsCount').textContent = `${students?.length || 0} طالب`;

    } catch (error) {
        console.error('Error loading class students:', error);
    }
}

// تحميل المحتوى الحديث
async function loadRecentContent() {
    try {
        const teacherId = window.AppState.currentUser.user_id;
        
        const { data: content, error } = await window.EduPath.supabase
            .from('content')
            .select(`
                *,
                classes!left (
                    name
                )
            `)
            .eq('teacher_id', teacherId)
            .order('created_at', { ascending: false })
            .limit(5);

        if (error) throw error;

        const container = document.getElementById('recentContent');
        container.innerHTML = '';

        if (content.length === 0) {
            container.innerHTML = `
                <div class="content-item empty">
                    <i class="fas fa-book-open"></i>
                    <p>لا يوجد محتوى بعد</p>
                    <button class="btn btn-primary btn-sm" onclick="switchToSection('content')">
                        <i class="fas fa-plus"></i>
                        إضافة أول محتوى
                    </button>
                </div>
            `;
            return;
        }

        content.forEach(item => {
            const itemEl = document.createElement('div');
            itemEl.className = 'content-item';
            itemEl.innerHTML = `
                <div class="content-icon">
                    <i class="fas ${item.type === 'lesson' ? 'fa-book-open' : 'fa-tasks'}"></i>
                </div>
                <div class="content-details">
                    <h4>${item.title}</h4>
                    <div class="content-meta">
                        <span class="meta-item">
                            <i class="fas fa-chalkboard"></i>
                            ${item.classes?.name || 'غير محدد'}
                        </span>
                        <span class="meta-item">
                            <i class="far fa-clock"></i>
                            ${window.Helpers.formatDate(item.created_at)}
                        </span>
                        <span class="meta-item">
                            <i class="fas fa-tag"></i>
                            ${item.type === 'lesson' ? 'درس' : 'واجب'}
                        </span>
                    </div>
                </div>
                <div class="content-actions">
                    <button class="btn btn-icon btn-sm" onclick="viewContent('${item.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            `;
            container.appendChild(itemEl);
        });

    } catch (error) {
        console.error('Error loading recent content:', error);
    }
}

// تحديث الإحصائيات
async function updateStatistics() {
    try {
        const teacherId = window.AppState.currentUser.user_id;
        
        // جلب إجمالي المحتوى
        const { data: content, error: contentError } = await window.EduPath.supabase
            .from('content')
            .select('*', { count: 'exact', head: true })
            .eq('teacher_id', teacherId);

        if (!contentError) {
            document.getElementById('totalContent').textContent = content.length;
        }

        // جلب عدد الطلاب المقييمين
        if (TeacherState.currentClass) {
            const { data: grades, error: gradesError } = await window.EduPath.supabase
                .from('grades')
                .select('student_id', { count: 'distinct' })
                .eq('class_id', TeacherState.currentClass.id)
                .eq('subject', window.AppState.currentUser.subject);

            if (!gradesError) {
                const gradedCount = grades.length;
                const totalStudents = TeacherState.students.length;
                const percentage = totalStudents > 0 ? Math.round((gradedCount / totalStudents) * 100) : 0;
                
                document.getElementById('gradedStudents').textContent = gradedCount;
                document.getElementById('gradedPercentage').textContent = `${percentage}%`;
            }
        }

    } catch (error) {
        console.error('Error updating statistics:', error);
    }
}

// عرض تفاصيل الصف
async function viewClassDetails() {
    if (!TeacherState.currentClass) {
        window.Helpers.showToast('ليس لديك صف معين', 'error');
        return;
    }

    try {
        // جلب تفاصيل الصف مع الطلاب
        const { data: students, error } = await window.EduPath.supabase
            .from('users')
            .select('*')
            .eq('current_class_id', TeacherState.currentClass.id)
            .eq('role', 'student')
            .order('full_name');

        if (error) throw error;

        document.getElementById('modalClassName').textContent = TeacherState.currentClass.name;
        
        document.getElementById('classDetailsContent').innerHTML = `
            <div class="class-info-section">
                <h4><i class="fas fa-info-circle"></i> معلومات الصف</h4>
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label">اسم الصف:</span>
                        <span class="info-value">${TeacherState.currentClass.name}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">عدد الطلاب:</span>
                        <span class="info-value">${students.length}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">التخصص:</span>
                        <span class="info-value">${window.AppState.currentUser.subject || 'غير محدد'}</span>
                    </div>
                </div>
            </div>

            <div class="students-section">
                <h4><i class="fas fa-user-graduate"></i> قائمة الطلاب</h4>
                <div class="students-list">
                    ${students.map(student => `
                        <div class="student-item">
                            <div class="student-avatar">
                                ${student.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                            </div>
                            <div class="student-info">
                                <span class="student-name">${student.full_name}</span>
                                <span class="student-code">${student.login_code || 'لا يوجد كود'}</span>
                            </div>
                            <button class="btn btn-icon btn-sm" onclick="sendMessageToStudent('${student.id}')">
                                <i class="fas fa-comment"></i>
                            </button>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;

        document.getElementById('classDetailsModal').style.display = 'block';

    } catch (error) {
        console.error('Error loading class details:', error);
        window.Helpers.showToast('خطأ في تحميل تفاصيل الصف', 'error');
    }
}

// إضافة واجب
function addHomework() {
    switchToSection('content');
    document.getElementById('contentType').value = 'homework';
    toggleHomeworkFields();
    
    // تفعيل زر النشر
    const publishBtn = document.querySelector('#uploadContentForm button[type="submit"]');
    publishBtn.innerHTML = '<i class="fas fa-tasks"></i> نشر الواجب';
}

// مراسلة الصف
async function sendMessageToClass() {
    if (!TeacherState.currentClass) {
        window.Helpers.showToast('ليس لديك صف معين', 'error');
        return;
    }

    // فتح نافذة المحادثة مع الصف
    window.Helpers.showToast('سيتم فتح نافذة المحادثة مع الصف', 'info');
    switchToSection('messages');
    // سيتم تنفيذها في قسم الرسائل
}

// عرض تقدم الطلاب
function viewStudentProgress() {
    switchToSection('grades');
    window.Helpers.showToast('جاري تحميل بيانات التقدم...', 'info');
}

// تحميل تقرير الصف
async function downloadClassReport() {
    if (!TeacherState.currentClass) {
        window.Helpers.showToast('ليس لديك صف معين', 'error');
        return;
    }

    try {
        window.Helpers.showToast('جاري تحضير التقرير...', 'info');
        
        // جلب بيانات الطلاب والدرجات
        const { data: grades, error } = await window.EduPath.supabase
            .from('grades')
            .select(`
                *,
                users!inner (
                    full_name
                )
            `)
            .eq('class_id', TeacherState.currentClass.id)
            .eq('subject', window.AppState.currentUser.subject);

        if (error) throw error;

        // تحضير التقرير
        const reportData = grades.map(grade => ({
            'اسم الطالب': grade.users.full_name,
            'الدرجة': grade.score,
            'المادة': grade.subject,
            'التاريخ': window.Helpers.formatDate(grade.created_at),
            'ملاحظات': grade.notes || 'لا يوجد'
        }));

        // تحويل إلى CSV وتنزيل
        const csv = convertToCSV(reportData);
        downloadCSV(csv, `تقرير_${TeacherState.currentClass.name}.csv`);
        
        window.Helpers.showToast('تم تحميل التقرير بنجاح', 'success');

    } catch (error) {
        console.error('Error downloading report:', error);
        window.Helpers.showToast('خطأ في تحميل التقرير', 'error');
    }
}

// تحويل البيانات إلى CSV
function convertToCSV(data) {
    const headers = Object.keys(data[0]);
    const rows = data.map(row => 
        headers.map(header => JSON.stringify(row[header])).join(',')
    );
    return [headers.join(','), ...rows].join('\n');
}

// تنزيل ملف CSV
function downloadCSV(csv, filename) {
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// تهيئة تحميل الملفات
function initializeFileUpload() {
    const uploadArea = document.getElementById('fileUploadArea');
    const fileInput = document.getElementById('fileInput');

    if (!uploadArea || !fileInput) return;

    // Drag and Drop
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.classList.add('dragover');
    });

    uploadArea.addEventListener('dragleave', function(e) {
        e.preventDefault();
        this.classList.remove('dragover');
    });

    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        this.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        handleFileSelect({ target: { files } });
    });

    // Click to select
    uploadArea.addEventListener('click', function() {
        fileInput.click();
    });
}

// معالجة اختيار الملفات
function handleFileSelect(event) {
    const files = event.target.files;
    const container = document.getElementById('selectedFiles');
    
    if (!container) return;
    
    container.innerHTML = '';
    TeacherState.selectedFiles = [];
    
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        // التحقق من حجم الملف
        if (file.size > 10 * 1024 * 1024) { // 10MB
            window.Helpers.showToast(`الملف ${file.name} يتجاوز الحد المسموح (10MB)`, 'error');
            continue;
        }
        
        TeacherState.selectedFiles.push(file);
        
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.innerHTML = `
            <div class="file-info">
                <i class="fas fa-file"></i>
                <div>
                    <span class="file-name">${file.name}</span>
                    <span class="file-size">${formatFileSize(file.size)}</span>
                </div>
            </div>
            <button class="btn btn-icon btn-sm btn-danger" onclick="removeFile(${i})">
                <i class="fas fa-times"></i>
            </button>
        `;
        container.appendChild(fileItem);
    }
}

// تنسيق حجم الملف
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// إزالة ملف
function removeFile(index) {
    TeacherState.selectedFiles.splice(index, 1);
    handleFileSelect({ target: { files: [] } }); // إعادة عرض الملفات المتبقية
}

// تهيئة الرسوم البيانية
function initializeCharts() {
    // تأجيل تهيئة الرسوم البيانية حتى يتم تحميل مكتبة Chart.js
    if (typeof Chart === 'undefined') {
        setTimeout(initializeCharts, 100);
        return;
    }

    // مخطط أداء الطلاب
    const perfCtx = document.getElementById('performanceChart');
    if (!perfCtx) return;
    
    TeacherState.charts.performance = new Chart(perfCtx.getContext('2d'), {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'متوسط الدرجات',
                data: [],
                backgroundColor: 'rgba(103, 58, 183, 0.7)',
                borderColor: 'rgba(103, 58, 183, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    rtl: true
                },
                tooltip: {
                    rtl: true,
                    callbacks: {
                        label: function(context) {
                            return `الدرجة: ${context.raw}%`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}

// تحديث مخطط الأداء
async function updatePerformanceChart() {
    const classId = document.getElementById('performanceClass');
    if (!classId) return;
    
    const selectedClassId = classId.value;
    if (!selectedClassId) return;

    try {
        const subject = window.AppState.currentUser.subject;
        
        // جلب درجات الطلاب في هذا الصف
        const { data: grades, error } = await window.EduPath.supabase
            .from('grades')
            .select(`
                *,
                users!inner (
                    full_name
                )
            `)
            .eq('class_id', selectedClassId)
            .eq('subject', subject);

        if (error) throw error;

        // تجميع الدرجات لكل طالب
        const studentGrades = {};
        grades.forEach(grade => {
            if (!studentGrades[grade.student_id]) {
                studentGrades[grade.student_id] = {
                    name: grade.users.full_name,
                    grades: []
                };
            }
            studentGrades[grade.student_id].grades.push(grade.score);
        });

        // حساب المتوسط لكل طالب
        const labels = [];
        const data = [];
        let totalAverage = 0;
        let improvedCount = 0;
        let declinedCount = 0;

        Object.values(studentGrades).forEach(student => {
            if (student.grades.length > 0) {
                const average = student.grades.reduce((a, b) => a + b, 0) / student.grades.length;
                labels.push(student.name);
                data.push(average.toFixed(1));
                totalAverage += average;

                // حساب التحسن/التراجع (مقارنة أول وآخر درجة)
                if (student.grades.length >= 2) {
                    const firstGrade = student.grades[0];
                    const lastGrade = student.grades[student.grades.length - 1];
                    
                    if (lastGrade > firstGrade) {
                        improvedCount++;
                    } else if (lastGrade < firstGrade) {
                        declinedCount++;
                    }
                }
            }
        });

        // تحديث الرسم البياني
        if (TeacherState.charts.performance) {
            TeacherState.charts.performance.data.labels = labels;
            TeacherState.charts.performance.data.datasets[0].data = data;
            TeacherState.charts.performance.update();
        }

        // تحديث الإحصائيات
        const studentCount = Object.keys(studentGrades).length;
        const overallAverage = studentCount > 0 ? (totalAverage / studentCount).toFixed(1) : 0;
        
        document.getElementById('avgPerformance').textContent = `${overallAverage}%`;
        document.getElementById('improvedCount').textContent = improvedCount;
        document.getElementById('declinedCount').textContent = declinedCount;

    } catch (error) {
        console.error('Error updating performance chart:', error);
    }
}

// مراسلة طالب معين
function sendMessageToStudent(studentId) {
    // البحث عن الطالب
    const student = TeacherState.students.find(s => s.id === studentId);
    if (student) {
        closeModal('classDetailsModal');
        switchToSection('messages');
        openConversation(student);
    }
}

// تحديث التخصص
function updateSubject() {
    document.getElementById('newSubject').value = window.AppState.currentUser.subject || '';
    document.getElementById('updateSubjectModal').style.display = 'block';
}

// معالجة تحديث التخصص
document.getElementById('updateSubjectForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const newSubject = document.getElementById('newSubject').value.trim();
    
    if (!newSubject) {
        window.Helpers.showToast('يرجى إدخال اسم المادة', 'error');
        return;
    }
    
    try {
        const teacherId = window.AppState.currentUser.user_id;
        
        const { error } = await window.EduPath.supabase
            .from('users')
            .update({ subject: newSubject })
            .eq('id', teacherId);

        if (error) throw error;

        // تحديث حالة التطبيق
        window.AppState.currentUser.subject = newSubject;
        window.AppState.setUser(window.AppState.currentUser);
        
        // تحديث الواجهة
        document.getElementById('teacherSubject').textContent = newSubject;
        document.getElementById('contentSubject').value = newSubject;
        
        window.Helpers.showToast('تم تحديث التخصص بنجاح', 'success');
        closeModal('updateSubjectModal');

    } catch (error) {
        console.error('Error updating subject:', error);
        window.Helpers.showToast('خطأ في تحديث التخصص', 'error');
    }
});

// إغلاق النافذة المنبثقة
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// تبديل قائمة الجوال
function toggleMobileMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('show');
}

// تفعيل Realtime
function setupRealtime() {
    // الاشتراك في تحديثات الرسائل
    const messagesChannel = window.EduPath.supabase.channel('teacher_messages_channel')
        .on('postgres_changes', 
            { 
                event: 'INSERT', 
                schema: 'public', 
                table: 'messages',
                filter: `receiver_id=eq.${window.AppState.currentUser.user_id}`
            }, 
            payload => {
                window.Helpers.showToast('رسالة جديدة', 'info');
                
                // إذا كانت المحادثة مفتوحة، تحديثها
                if (TeacherState.currentConversation && 
                    payload.new.sender_id === TeacherState.currentConversation.user.id) {
                    loadConversationMessages(TeacherState.currentConversation.user.id);
                }
                
                // تحديث قائمة المحادثات
                loadConversations();
            }
        )
        .subscribe();

    // الاشتراك في تحديثات الإشعارات
    const notificationsChannel = window.EduPath.supabase.channel('teacher_notifications_channel')
        .on('postgres_changes',
            {
                event: 'INSERT',
                schema: 'public',
                table: 'notifications',
                filter: `user_id=eq.${window.AppState.currentUser.user_id}`
            },
            payload => {
                window.Helpers.showToast('إشعار جديد', 'info');
            }
        )
        .subscribe();
}

// تحميل قسم المحتوى (يتم استدعاؤه من loadSection)
async function loadContentSection(container) {
    const response = await fetch('content-section.html');
    const html = await response.text();
    container.innerHTML = html;
    
    // تهيئة المحتوى التعليمي
    if (typeof initializeContentSection === 'function') {
        initializeContentSection();
    }
}

// تحميل قسم الدرجات (يتم استدعاؤه من loadSection)
async function loadGradesSection(container) {
    const response = await fetch('grades-section.html');
    const html = await response.text();
    container.innerHTML = html;
    
    // تهيئة قسم الدرجات
    if (typeof initializeGradesSection === 'function') {
        initializeGradesSection();
    }
}

// تحميل قسم الرسائل (يتم استدعاؤه من loadSection)
async function loadMessagesSection(container) {
    const response = await fetch('messages-section.html');
    const html = await response.text();
    container.innerHTML = html;
    
    // تهيئة قسم الرسائل
    if (typeof initializeMessagesSection === 'function') {
        initializeMessagesSection();
    }
}

// تصدير الوظائف العامة
window.TeacherDashboard = {
    TeacherState,
    switchToSection,
    viewClassDetails,
    addHomework,
    sendMessageToClass,
    viewStudentProgress,
    downloadClassReport,
    updateSubject,
    closeModal,
    toggleMobileMenu,
    sendMessageToStudent
};