// قسم رصد وتقييم الدرجات

// تهيئة قسم الدرجات
function initializeGradesSection() {
    console.log('Initializing grades section...');
    
    // تحميل بيانات التقييم
    loadGradingData();
    
    // إضافة معالجات الأحداث
    const gradeClassSelect = document.getElementById('gradeClassSelect');
    if (gradeClassSelect) {
        gradeClassSelect.addEventListener('change', loadStudentsForGrading);
    }
    
    const gradeAssignment = document.getElementById('gradeAssignment');
    if (gradeAssignment) {
        gradeAssignment.addEventListener('input', function() {
            if (TeacherState.gradingData.classId) {
                loadStudentsForGrading();
            }
        });
    }
    
    // إضافة معالجات الأزرار
    const resetBtn = document.querySelector('button[onclick="resetGrades()"]');
    if (resetBtn) {
        resetBtn.onclick = resetGrades;
    }
    
    const saveAllBtn = document.querySelector('button[onclick="saveAllGrades()"]');
    if (saveAllBtn) {
        saveAllBtn.onclick = saveAllGrades;
    }
    
    const publishBtn = document.querySelector('button[onclick="publishGrades()"]');
    if (publishBtn) {
        publishBtn.onclick = publishGrades;
    }
    
    // تهيئة مخططات الأداء
    initializeCharts();
}

// تحميل بيانات التقييم
async function loadGradingData() {
    // إذا كان هناك صف محدد مسبقاً، تحميل طلابه
    const gradeClassSelect = document.getElementById('gradeClassSelect');
    if (gradeClassSelect && gradeClassSelect.value) {
        await loadStudentsForGrading();
    }
    
    // تحميل سجل الدرجات
    await loadGradesHistory();
    
    // تهيئة مخطط الأداء
    await updatePerformanceChart();
}

// تحميل الطلاب للتقييم
async function loadStudentsForGrading() {
    const classId = document.getElementById('gradeClassSelect').value;
    const assignment = document.getElementById('gradeAssignment').value.trim();
    
    if (!classId) {
        const selectionPrompt = document.getElementById('gradeSelectionPrompt');
        const tableContainer = document.getElementById('gradingTableContainer');
        
        if (selectionPrompt) selectionPrompt.style.display = 'block';
        if (tableContainer) tableContainer.style.display = 'none';
        return;
    }

    if (!assignment) {
        window.Helpers.showToast('يرجى إدخال عنوان التقييم', 'error');
        return;
    }

    try {
        TeacherState.gradingData.classId = classId;
        TeacherState.gradingData.assignment = assignment;

        // جلب الصف المحدد
        const selectedClass = TeacherState.classes.find(c => c.id === classId);
        if (selectedClass) {
            const gradingClassName = document.getElementById('gradingClassName');
            if (gradingClassName) {
                gradingClassName.textContent = selectedClass.name;
            }
        }

        // جلب الطلاب
        const { data: students, error } = await window.EduPath.supabase
            .from('users')
            .select('*')
            .eq('current_class_id', classId)
            .eq('role', 'student')
            .order('full_name');

        if (error) throw error;

        // جلب الدرجات السابقة لهذا التقييم
        const { data: existingGrades, error: gradesError } = await window.EduPath.supabase
            .from('grades')
            .select('*')
            .eq('class_id', classId)
            .eq('subject', window.AppState.currentUser.subject)
            .ilike('notes', `%${assignment}%`);

        // إعداد بيانات الدرجات
        TeacherState.gradingData.grades = {};
        if (!gradesError && existingGrades.length > 0) {
            existingGrades.forEach(grade => {
                TeacherState.gradingData.grades[grade.student_id] = {
                    score: grade.score,
                    notes: grade.notes
                };
            });
        }

        // عرض جدول التقييم
        displayGradingTable(students, assignment);

        // تحديث معلومات التقييم
        const gradingStudentsCount = document.getElementById('gradingStudentsCount');
        const gradingAssignment = document.getElementById('gradingAssignment');
        const selectionPrompt = document.getElementById('gradeSelectionPrompt');
        const tableContainer = document.getElementById('gradingTableContainer');
        
        if (gradingStudentsCount) gradingStudentsCount.textContent = students.length;
        if (gradingAssignment) gradingAssignment.textContent = assignment;
        if (selectionPrompt) selectionPrompt.style.display = 'none';
        if (tableContainer) tableContainer.style.display = 'block';

        // بدء الحفظ التلقائي
        startAutoSave();

    } catch (error) {
        console.error('Error loading students for grading:', error);
        window.Helpers.showToast('خطأ في تحميل بيانات الطلاب', 'error');
    }
}

// عرض جدول التقييم
function displayGradingTable(students, assignment) {
    const tbody = document.getElementById('gradingTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    let totalScore = 0;
    let gradedCount = 0;
    let highestScore = 0;
    let lowestScore = 100;
    
    students.forEach(student => {
        const existingGrade = TeacherState.gradingData.grades[student.id];
        const score = existingGrade?.score || '';
        const notes = existingGrade?.notes || '';
        
        if (score !== '') {
            const numericScore = parseFloat(score);
            totalScore += numericScore;
            gradedCount++;
            highestScore = Math.max(highestScore, numericScore);
            lowestScore = Math.min(lowestScore, numericScore);
        }
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="student-name">
                <div class="student-info-small">
                    <div class="avatar-small">
                        ${student.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                    </div>
                    <span>${student.full_name}</span>
                </div>
            </td>
            <td>
                <div class="grade-input-container">
                    <input 
                        type="number" 
                        class="grade-input"
                        value="${score}"
                        min="0"
                        max="100"
                        step="0.5"
                        data-student-id="${student.id}"
                        onchange="updateGrade('${student.id}', this.value)"
                        placeholder="0-100"
                    >
                    <span class="grade-suffix">/100</span>
                </div>
            </td>
            <td>
                <span class="percentage-display">
                    ${score ? `${score}%` : '--'}
                </span>
            </td>
            <td>
                <input 
                    type="text" 
                    class="notes-input"
                    value="${notes}"
                    placeholder="ملاحظات..."
                    data-student-id="${student.id}"
                    onchange="updateNotes('${student.id}', this.value)"
                >
            </td>
            <td>
                <span class="status-badge ${score ? 'graded' : 'pending'}">
                    <i class="fas ${score ? 'fa-check-circle' : 'fa-clock'}"></i>
                    ${score ? 'تم التقييم' : 'قيد الانتظار'}
                </span>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    // تحديث الملخص
    updateGradingSummary();
}

// تحديث درجة طالب
function updateGrade(studentId, score) {
    if (!TeacherState.gradingData.grades[studentId]) {
        TeacherState.gradingData.grades[studentId] = {};
    }
    
    TeacherState.gradingData.grades[studentId].score = score;
    
    // تحديث حالة الصف
    const gradeInput = document.querySelector(`input[data-student-id="${studentId}"]`);
    if (!gradeInput) return;
    
    const row = gradeInput.closest('tr');
    const statusBadge = row.querySelector('.status-badge');
    const percentageDisplay = row.querySelector('.percentage-display');
    
    if (score && score !== '') {
        statusBadge.className = 'status-badge graded';
        statusBadge.innerHTML = '<i class="fas fa-check-circle"></i> تم التقييم';
        percentageDisplay.textContent = `${score}%`;
    } else {
        statusBadge.className = 'status-badge pending';
        statusBadge.innerHTML = '<i class="fas fa-clock"></i> قيد الانتظار';
        percentageDisplay.textContent = '--';
    }
    
    // تحديث الملخص
    updateGradingSummary();
}

// تحديث ملاحظات طالب
function updateNotes(studentId, notes) {
    if (!TeacherState.gradingData.grades[studentId]) {
        TeacherState.gradingData.grades[studentId] = {};
    }
    
    TeacherState.gradingData.grades[studentId].notes = notes;
}

// تحديث ملخص التقييم
function updateGradingSummary() {
    const rows = document.querySelectorAll('#gradingTableBody tr');
    let totalScore = 0;
    let gradedCount = 0;
    let highestScore = 0;
    let lowestScore = 100;
    
    rows.forEach(row => {
        const scoreInput = row.querySelector('.grade-input');
        const score = parseFloat(scoreInput.value);
        
        if (!isNaN(score)) {
            totalScore += score;
            gradedCount++;
            highestScore = Math.max(highestScore, score);
            lowestScore = Math.min(lowestScore, score);
        }
    });
    
    const average = gradedCount > 0 ? (totalScore / gradedCount).toFixed(1) : 0;
    
    const averageGrade = document.getElementById('averageGrade');
    const highestGrade = document.getElementById('highestGrade');
    const lowestGrade = document.getElementById('lowestGrade');
    const gradedCountElement = document.getElementById('gradedCount');
    
    if (averageGrade) averageGrade.textContent = `${average}%`;
    if (highestGrade) highestGrade.textContent = `${highestScore}%`;
    if (lowestGrade) lowestGrade.textContent = `${lowestScore}%`;
    if (gradedCountElement) gradedCountElement.textContent = `${gradedCount}/${rows.length}`;
}

// بدء الحفظ التلقائي
function startAutoSave() {
    // إيقاف المؤقت السابق إذا كان موجوداً
    if (TeacherState.gradingData.autoSaveTimer) {
        clearInterval(TeacherState.gradingData.autoSaveTimer);
    }
    
    // بدء مؤتمر جديد للحفظ التلقائي كل 10 ثوان
    TeacherState.gradingData.autoSaveTimer = setInterval(() => {
        saveAllGrades(true); // true يعني أن الحفظ تلقائي
    }, 10000);
    
    const autoSaveStatus = document.getElementById('autoSaveStatus');
    if (autoSaveStatus) {
        autoSaveStatus.className = 'fas fa-circle text-success';
    }
}

// إيقاف الحفظ التلقائي
function stopAutoSave() {
    if (TeacherState.gradingData.autoSaveTimer) {
        clearInterval(TeacherState.gradingData.autoSaveTimer);
        TeacherState.gradingData.autoSaveTimer = null;
    }
    
    const autoSaveStatus = document.getElementById('autoSaveStatus');
    if (autoSaveStatus) {
        autoSaveStatus.className = 'fas fa-circle text-danger';
    }
}

// حفظ جميع الدرجات
async function saveAllGrades(isAutoSave = false) {
    const classId = TeacherState.gradingData.classId;
    const assignment = TeacherState.gradingData.assignment;
    
    if (!classId || !assignment) {
        if (!isAutoSave) {
            window.Helpers.showToast('يرجى تحديد الصف وعنوان التقييم أولاً', 'error');
        }
        return;
    }
    
    const grades = Object.entries(TeacherState.gradingData.grades);
    if (grades.length === 0) {
        if (!isAutoSave) {
            window.Helpers.showToast('لا توجد درجات لحفظها', 'info');
        }
        return;
    }
    
    try {
        // حفظ كل درجة
        let savedCount = 0;
        const subject = window.AppState.currentUser.subject;
        
        for (const [studentId, gradeData] of grades) {
            if (gradeData.score && gradeData.score !== '') {
                const { error } = await window.EduPath.supabase
                    .from('grades')
                    .upsert([{
                        student_id: studentId,
                        class_id: classId,
                        subject: subject,
                        score: parseFloat(gradeData.score),
                        notes: `${assignment}: ${gradeData.notes || ''}`.trim()
                    }], {
                        onConflict: 'student_id,class_id,subject'
                    });
                
                if (error) throw error;
                savedCount++;
            }
        }
        
        if (!isAutoSave) {
            window.Helpers.showToast(`تم حفظ ${savedCount} درجة`, 'success');
        }
        
        // تحديث سجل الدرجات
        await loadGradesHistory();
        
    } catch (error) {
        console.error('Error saving grades:', error);
        if (!isAutoSave) {
            window.Helpers.showToast('خطأ في حفظ الدرجات', 'error');
        }
    }
}

// إعادة تعيين الدرجات
function resetGrades() {
    if (!confirm('هل أنت متأكد من إعادة تعيين جميع الدرجات؟')) {
        return;
    }
    
    const inputs = document.querySelectorAll('.grade-input, .notes-input');
    inputs.forEach(input => {
        input.value = '';
    });
    
    TeacherState.gradingData.grades = {};
    updateGradingSummary();
    window.Helpers.showToast('تم إعادة تعيين الدرجات', 'success');
}

// نشر الدرجات
async function publishGrades() {
    // حفظ الدرجات أولاً
    await saveAllGrades();
    
    // إرسال إشعارات للطلاب
    try {
        const classId = TeacherState.gradingData.classId;
        const assignment = TeacherState.gradingData.assignment;
        
        // جلب طلاب الصف
        const { data: students, error } = await window.EduPath.supabase
            .from('users')
            .select('id')
            .eq('current_class_id', classId)
            .eq('role', 'student');
        
        if (error) throw error;
        
        // إرسال إشعار لكل طالب
        const notifications = students.map(student => ({
            user_id: student.id,
            message: `تم تقييم ${assignment}. يمكنك الاطلاع على درجاتك.`,
            is_read: false
        }));
        
        const { error: notifyError } = await window.EduPath.supabase
            .from('notifications')
            .insert(notifications);
        
        if (notifyError) throw notifyError;
        
        window.Helpers.showToast(`تم نشر الدرجات وإرسال إشعار لـ ${students.length} طالب`, 'success');
        
    } catch (error) {
        console.error('Error publishing grades:', error);
        window.Helpers.showToast('تم حفظ الدرجات ولكن حدث خطأ في إرسال الإشعارات', 'warning');
    }
}

// تحميل سجل الدرجات
async function loadGradesHistory() {
    try {
        const teacherId = window.AppState.currentUser.user_id;
        const subject = window.AppState.currentUser.subject;
        
        const { data: grades, error } = await window.EduPath.supabase
            .from('grades')
            .select(`
                *,
                users!inner (
                    full_name
                ),
                classes!inner (
                    name
                )
            `)
            .eq('subject', subject)
            .order('created_at', { ascending: false })
            .limit(20);

        if (error) throw error;

        const container = document.getElementById('gradesHistory');
        if (!container) return;
        
        container.innerHTML = '';

        if (grades.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-star"></i>
                    <p>لا توجد درجات مسجلة بعد</p>
                </div>
            `;
            return;
        }

        grades.forEach(grade => {
            const gradeItem = document.createElement('div');
            gradeItem.className = 'grade-history-item';
            gradeItem.innerHTML = `
                <div class="grade-icon">
                    <i class="fas fa-star"></i>
                </div>
                <div class="grade-info">
                    <div class="grade-header">
                        <h4>${grade.users.full_name}</h4>
                        <span class="grade-score">${grade.score}%</span>
                    </div>
                    <div class="grade-details">
                        <span class="detail-item">
                            <i class="fas fa-chalkboard"></i>
                            ${grade.classes.name}
                        </span>
                        <span class="detail-item">
                            <i class="far fa-clock"></i>
                            ${window.Helpers.formatDate(grade.created_at)}
                        </span>
                    </div>
                    ${grade.notes ? `
                        <div class="grade-notes">
                            <i class="fas fa-sticky-note"></i>
                            <span>${grade.notes}</span>
                        </div>
                    ` : ''}
                </div>
            `;
            container.appendChild(gradeItem);
        });

    } catch (error) {
        console.error('Error loading grades history:', error);
    }
}

// تهيئة الرسوم البيانية
function initializeCharts() {
    // تأجيل تهيئة الرسوم البيانية حتى يتم تحميل مكتبة Chart.js
    if (typeof Chart === 'undefined') {
        setTimeout(initializeCharts, 100);
        return;
    }

    // مخطط أداء الطلاب
    const perfCtx = document.getElementById('performanceChart');
    if (!perfCtx) return;
    
    TeacherState.charts.performance = new Chart(perfCtx.getContext('2d'), {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'متوسط الدرجات',
                data: [],
                backgroundColor: 'rgba(103, 58, 183, 0.7)',
                borderColor: 'rgba(103, 58, 183, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    rtl: true
                },
                tooltip: {
                    rtl: true,
                    callbacks: {
                        label: function(context) {
                            return `الدرجة: ${context.raw}%`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}

// تحديث مخطط الأداء
async function updatePerformanceChart() {
    const performanceClass = document.getElementById('performanceClass');
    if (!performanceClass) return;
    
    const classId = performanceClass.value;
    if (!classId) return;

    try {
        const subject = window.AppState.currentUser.subject;
        
        // جلب درجات الطلاب في هذا الصف
        const { data: grades, error } = await window.EduPath.supabase
            .from('grades')
            .select(`
                *,
                users!inner (
                    full_name
                )
            `)
            .eq('class_id', classId)
            .eq('subject', subject);

        if (error) throw error;

        // تجميع الدرجات لكل طالب
        const studentGrades = {};
        grades.forEach(grade => {
            if (!studentGrades[grade.student_id]) {
                studentGrades[grade.student_id] = {
                    name: grade.users.full_name,
                    grades: []
                };
            }
            studentGrades[grade.student_id].grades.push(grade.score);
        });

        // حساب المتوسط لكل طالب
        const labels = [];
        const data = [];
        let totalAverage = 0;
        let improvedCount = 0;
        let declinedCount = 0;

        Object.values(studentGrades).forEach(student => {
            if (student.grades.length > 0) {
                const average = student.grades.reduce((a, b) => a + b, 0) / student.grades.length;
                labels.push(student.name);
                data.push(average.toFixed(1));
                totalAverage += average;

                // حساب التحسن/التراجع (مقارنة أول وآخر درجة)
                if (student.grades.length >= 2) {
                    const firstGrade = student.grades[0];
                    const lastGrade = student.grades[student.grades.length - 1];
                    
                    if (lastGrade > firstGrade) {
                        improvedCount++;
                    } else if (lastGrade < firstGrade) {
                        declinedCount++;
                    }
                }
            }
        });

        // تحديث الرسم البياني
        if (TeacherState.charts.performance) {
            TeacherState.charts.performance.data.labels = labels;
            TeacherState.charts.performance.data.datasets[0].data = data;
            TeacherState.charts.performance.update();
        }

        // تحديث الإحصائيات
        const studentCount = Object.keys(studentGrades).length;
        const overallAverage = studentCount > 0 ? (totalAverage / studentCount).toFixed(1) : 0;
        
        const avgPerformance = document.getElementById('avgPerformance');
        const improvedCountElement = document.getElementById('improvedCount');
        const declinedCountElement = document.getElementById('declinedCount');
        
        if (avgPerformance) avgPerformance.textContent = `${overallAverage}%`;
        if (improvedCountElement) improvedCountElement.textContent = improvedCount;
        if (declinedCountElement) declinedCountElement.textContent = declinedCount;

    } catch (error) {
        console.error('Error updating performance chart:', error);
    }
}

// تصدير الوظائف العامة
window.TeacherGrades = {
    initializeGradesSection,
    loadGradingData,
    loadStudentsForGrading,
    updateGrade,
    updateNotes,
    saveAllGrades,
    resetGrades,
    publishGrades,
    updatePerformanceChart
};