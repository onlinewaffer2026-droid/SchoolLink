// قسم إدارة المحتوى التعليمي

// تهيئة قسم المحتوى
function initializeContentSection() {
    console.log('Initializing content section...');
    
    // تحديث أعداد المحتوى
    updateContentCounts();
    
    // تحميل البيانات حسب التبويب الحالي
    if (TeacherState.currentContentTab === 'upload') {
        // لا يحتاج تحميل بيانات إضافية
    } else if (TeacherState.currentContentTab === 'lessons') {
        loadLessons();
    } else if (TeacherState.currentContentTab === 'homework') {
        loadHomework();
    } else if (TeacherState.currentContentTab === 'all') {
        loadAllContent();
    }
    
    // إضافة معالج النموذج
    const uploadForm = document.getElementById('uploadContentForm');
    if (uploadForm) {
        uploadForm.addEventListener('submit', handleContentUpload);
    }
}

// تبديل تبويبات المحتوى
function switchContentTab(tabName) {
    // تحديث التبويبات
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // تفعيل التبويب المحدد
    const tabButton = document.querySelector(`.tab[onclick*="${tabName}"]`);
    if (tabButton) {
        tabButton.classList.add('active');
    }
    
    const tabContent = document.getElementById(`${tabName}Tab`);
    if (tabContent) {
        tabContent.classList.add('active');
    }
    
    TeacherState.currentContentTab = tabName;
    
    // تحميل البيانات حسب التبويب
    switch(tabName) {
        case 'lessons':
            loadLessons();
            break;
        case 'homework':
            loadHomework();
            break;
        case 'all':
            loadAllContent();
            break;
    }
}

// تبديل عرض حقول الواجب
function toggleHomeworkFields() {
    const contentType = document.getElementById('contentType');
    if (!contentType) return;
    
    const contentTypeValue = contentType.value;
    const homeworkFields = document.getElementById('homeworkFields');
    
    if (contentTypeValue === 'homework') {
        homeworkFields.style.display = 'block';
    } else {
        homeworkFields.style.display = 'none';
    }
}

// إعادة تعيين نموذج الرفع
function resetUploadForm() {
    const form = document.getElementById('uploadContentForm');
    if (form) {
        form.reset();
    }
    
    const selectedFiles = document.getElementById('selectedFiles');
    if (selectedFiles) {
        selectedFiles.innerHTML = '';
    }
    
    TeacherState.selectedFiles = [];
    
    // إعادة تعيين القيم الافتراضية
    if (TeacherState.currentClass) {
        const contentClass = document.getElementById('contentClass');
        if (contentClass) {
            contentClass.value = TeacherState.currentClass.id;
        }
    }
    
    const contentSubject = document.getElementById('contentSubject');
    if (contentSubject) {
        contentSubject.value = window.AppState.currentUser.subject || '';
    }
    
    toggleHomeworkFields();
}

// تحديث أعداد المحتوى
async function updateContentCounts() {
    try {
        const teacherId = window.AppState.currentUser.user_id;
        
        // جلب عدد الدروس
        const { data: lessons, error: lessonsError } = await window.EduPath.supabase
            .from('content')
            .select('*', { count: 'exact', head: true })
            .eq('teacher_id', teacherId)
            .eq('type', 'lesson');

        if (!lessonsError) {
            const lessonsCount = document.getElementById('lessonsCount');
            if (lessonsCount) {
                lessonsCount.textContent = lessons.length;
            }
        }

        // جلب عدد الواجبات
        const { data: homework, error: homeworkError } = await window.EduPath.supabase
            .from('content')
            .select('*', { count: 'exact', head: true })
            .eq('teacher_id', teacherId)
            .eq('type', 'homework');

        if (!homeworkError) {
            const homeworkCount = document.getElementById('homeworkCount');
            if (homeworkCount) {
                homeworkCount.textContent = homework.length;
            }
        }

        // جلب إجمالي المحتوى
        const { data: allContent, error: allError } = await window.EduPath.supabase
            .from('content')
            .select('*', { count: 'exact', head: true })
            .eq('teacher_id', teacherId);

        if (!allError) {
            const allContentCount = document.getElementById('allContentCount');
            if (allContentCount) {
                allContentCount.textContent = allContent.length;
            }
        }

    } catch (error) {
        console.error('Error updating content counts:', error);
    }
}

// معالجة رفع المحتوى
async function handleContentUpload(e) {
    e.preventDefault();

    const contentType = document.getElementById('contentType').value;
    const title = document.getElementById('contentTitle').value.trim();
    const subject = document.getElementById('contentSubject').value;
    const classId = document.getElementById('contentClass').value;
    const description = document.getElementById('contentDescription').value.trim();
    const dueDate = document.getElementById('dueDate').value;
    const maxScore = document.getElementById('maxScore').value;
    const sendNotification = document.getElementById('sendNotification').checked;
    const publishNow = document.getElementById('publishNow').checked;

    // التحقق من البيانات
    if (!title || !subject || !classId) {
        window.Helpers.showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
        return;
    }

    if (contentType === 'homework' && (!dueDate || !maxScore)) {
        window.Helpers.showToast('يرجى إدخال تاريخ التسليم والدرجة الكاملة للواجب', 'error');
        return;
    }

    try {
        // إظهار مؤشر التحميل
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الرفع...';
        submitBtn.disabled = true;

        // رفع الملفات المرفقة أولاً
        let attachmentUrls = [];
        if (TeacherState.selectedFiles.length > 0) {
            window.Helpers.showToast('جاري رفع الملفات المرفقة...', 'info');
            
            for (const file of TeacherState.selectedFiles) {
                const result = await window.Helpers.uploadFile(file, 'eduPathContent');
                if (result.success) {
                    attachmentUrls.push(result.url);
                }
            }
            
            window.Helpers.showToast(`تم رفع ${attachmentUrls.length} ملف`, 'success');
        }

        // إعداد بيانات المحتوى
        const contentData = {
            class_id: classId,
            teacher_id: window.AppState.currentUser.user_id,
            title: title,
            description: description,
            type: contentType,
            subject: subject
        };

        // إضافة بيانات إضافية للواجبات
        if (contentType === 'homework') {
            contentData.due_date = dueDate;
            contentData.max_score = parseInt(maxScore);
        }

        // إضافة روابط المرفقات إذا وجدت
        if (attachmentUrls.length > 0) {
            contentData.attachment_url = attachmentUrls.join(',');
        }

        // حفظ المحتوى في قاعدة البيانات
        const { data: content, error } = await window.EduPath.supabase
            .from('content')
            .insert([contentData])
            .select()
            .single();

        if (error) throw error;

        // إرسال إشعارات للطلاب إذا طُلب
        if (sendNotification) {
            await sendContentNotification(content);
        }

        window.Helpers.showToast(`تم ${contentType === 'lesson' ? 'رفع الدرس' : 'إضافة الواجب'} بنجاح`, 'success');
        
        // إعادة تعيين النموذج
        resetUploadForm();
        
        // تحديث البيانات
        await updateContentCounts();
        await loadRecentContent();
        
        // الانتقال إلى قائمة المحتوى
        switchContentTab(contentType === 'lesson' ? 'lessons' : 'homework');

    } catch (error) {
        console.error('Error uploading content:', error);
        window.Helpers.showToast(`خطأ في ${contentType === 'lesson' ? 'رفع الدرس' : 'إضافة الواجب'}`, 'error');
    } finally {
        // استعادة حالة الزر
        const submitBtn = document.querySelector('#uploadContentForm button[type="submit"]');
        if (submitBtn) {
            submitBtn.innerHTML = originalText || '<i class="fas fa-paper-plane"></i> نشر المحتوى';
            submitBtn.disabled = false;
        }
    }
}

// إرسال إشعار للمحتوى
async function sendContentNotification(content) {
    try {
        // جلب طلاب الصف
        const { data: students, error } = await window.EduPath.supabase
            .from('users')
            .select('id')
            .eq('current_class_id', content.class_id)
            .eq('role', 'student');

        if (error) throw error;

        // إرسال إشعار لكل طالب
        const notifications = students.map(student => ({
            user_id: student.id,
            message: `${content.type === 'lesson' ? 'درس جديد' : 'واجب جديد'}: ${content.title}`,
            is_read: false
        }));

        const { error: notifyError } = await window.EduPath.supabase
            .from('notifications')
            .insert(notifications);

        if (notifyError) throw notifyError;

        window.Helpers.showToast(`تم إرسال إشعار لـ ${students.length} طالب`, 'success');

    } catch (error) {
        console.error('Error sending notifications:', error);
    }
}

// تحميل الدروس
async function loadLessons() {
    try {
        const teacherId = window.AppState.currentUser.user_id;
        
        const { data: lessons, error } = await window.EduPath.supabase
            .from('content')
            .select(`
                *,
                classes!left (
                    name
                )
            `)
            .eq('teacher_id', teacherId)
            .eq('type', 'lesson')
            .order('created_at', { ascending: false });

        if (error) throw error;

        const container = document.getElementById('lessonsGrid');
        if (!container) return;
        
        container.innerHTML = '';

        if (lessons.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-book-open"></i>
                    <p>لا توجد دروس بعد</p>
                    <button class="btn btn-primary" onclick="switchContentTab('upload')">
                        <i class="fas fa-plus"></i>
                        إضافة أول درس
                    </button>
                </div>
            `;
            return;
        }

        lessons.forEach(lesson => {
            const lessonCard = document.createElement('div');
            lessonCard.className = 'lesson-card';
            lessonCard.innerHTML = `
                <div class="lesson-header">
                    <div class="lesson-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="lesson-info">
                        <h3>${lesson.title}</h3>
                        <div class="lesson-meta">
                            <span class="meta-item">
                                <i class="fas fa-chalkboard"></i>
                                ${lesson.classes?.name || 'غير محدد'}
                            </span>
                            <span class="meta-item">
                                <i class="far fa-clock"></i>
                                ${window.Helpers.formatDate(lesson.created_at)}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="lesson-content">
                    <p>${lesson.description || 'لا يوجد وصف'}</p>
                </div>
                ${lesson.attachment_url ? `
                    <div class="lesson-attachments">
                        <i class="fas fa-paperclip"></i>
                        <span>${lesson.attachment_url.split(',').length} مرفق</span>
                    </div>
                ` : ''}
                <div class="lesson-footer">
                    <button class="btn btn-sm btn-outline" onclick="viewContent('${lesson.id}')">
                        <i class="fas fa-eye"></i>
                        عرض
                    </button>
                    <button class="btn btn-sm btn-primary" onclick="editContent('${lesson.id}')">
                        <i class="fas fa-edit"></i>
                        تعديل
                    </button>
                </div>
            `;
            container.appendChild(lessonCard);
        });

    } catch (error) {
        console.error('Error loading lessons:', error);
        window.Helpers.showToast('خطأ في تحميل الدروس', 'error');
    }
}

// تصفية الدروس
function filterLessons() {
    const classFilter = document.getElementById('lessonFilter');
    if (!classFilter) return;
    
    const filterValue = classFilter.value;
    const lessons = document.querySelectorAll('.lesson-card');
    
    lessons.forEach(lesson => {
        const classElement = lesson.querySelector('.lesson-meta .meta-item:nth-child(1)');
        const className = classElement?.textContent || '';
        const classMatch = !filterValue || className.includes(filterValue);
        
        lesson.style.display = classMatch ? 'block' : 'none';
    });
}

// تحميل الواجبات
async function loadHomework() {
    try {
        const teacherId = window.AppState.currentUser.user_id;
        
        const { data: homeworkList, error } = await window.EduPath.supabase
            .from('content')
            .select(`
                *,
                classes!left (
                    name
                )
            `)
            .eq('teacher_id', teacherId)
            .eq('type', 'homework')
            .order('created_at', { ascending: false });

        if (error) throw error;

        const container = document.getElementById('homeworkList');
        if (!container) return;
        
        container.innerHTML = '';

        if (homeworkList.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-tasks"></i>
                    <p>لا توجد واجبات بعد</p>
                    <button class="btn btn-primary" onclick="addHomework()">
                        <i class="fas fa-plus"></i>
                        إضافة أول واجب
                    </button>
                </div>
            `;
            return;
        }

        homeworkList.forEach(homework => {
            const homeworkItem = document.createElement('div');
            homeworkItem.className = 'homework-item';
            
            // حساب حالة الواجب
            const dueDate = homework.due_date ? new Date(homework.due_date) : null;
            const now = new Date();
            const isOverdue = dueDate && dueDate < now;
            const daysLeft = dueDate ? Math.ceil((dueDate - now) / (1000 * 60 * 60 * 24)) : null;
            
            let status = 'مستقبلي';
            let statusClass = 'badge-primary';
            
            if (isOverdue) {
                status = 'متأخر';
                statusClass = 'badge-danger';
            } else if (daysLeft !== null && daysLeft <= 3) {
                status = `متبقي ${daysLeft} يوم`;
                statusClass = 'badge-warning';
            } else if (daysLeft !== null) {
                status = `متبقي ${daysLeft} يوم`;
                statusClass = 'badge-success';
            }
            
            homeworkItem.innerHTML = `
                <div class="homework-header">
                    <div class="homework-icon">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="homework-info">
                        <h3>${homework.title}</h3>
                        <div class="homework-meta">
                            <span class="meta-item">
                                <i class="fas fa-chalkboard"></i>
                                ${homework.classes?.name || 'غير محدد'}
                            </span>
                            <span class="meta-item">
                                <i class="far fa-clock"></i>
                                ${window.Helpers.formatDate(homework.created_at)}
                            </span>
                            ${homework.due_date ? `
                                <span class="meta-item">
                                    <i class="fas fa-calendar-times"></i>
                                    ${new Date(homework.due_date).toLocaleDateString('ar-EG')}
                                </span>
                            ` : ''}
                        </div>
                    </div>
                    <div class="homework-status">
                        <span class="badge ${statusClass}">${status}</span>
                    </div>
                </div>
                <div class="homework-content">
                    <p>${homework.description || 'لا يوجد وصف'}</p>
                </div>
                <div class="homework-details">
                    <div class="detail-item">
                        <i class="fas fa-star"></i>
                        <span>الدرجة الكاملة: ${homework.max_score || 100}</span>
                    </div>
                    ${homework.attachment_url ? `
                        <div class="detail-item">
                            <i class="fas fa-paperclip"></i>
                            <span>${homework.attachment_url.split(',').length} مرفق</span>
                        </div>
                    ` : ''}
                </div>
                <div class="homework-footer">
                    <button class="btn btn-sm btn-outline" onclick="viewContent('${homework.id}')">
                        <i class="fas fa-eye"></i>
                        عرض
                    </button>
                    <button class="btn btn-sm btn-primary" onclick="gradeHomework('${homework.id}')">
                        <i class="fas fa-star"></i>
                        تقييم
                    </button>
                    <button class="btn btn-sm btn-success" onclick="viewSubmissions('${homework.id}')">
                        <i class="fas fa-file-upload"></i>
                        التقديمات
                    </button>
                </div>
            `;
            container.appendChild(homeworkItem);
        });

    } catch (error) {
        console.error('Error loading homework:', error);
        window.Helpers.showToast('خطأ في تحميل الواجبات', 'error');
    }
}

// تصفية الواجبات
function filterHomework() {
    const classFilter = document.getElementById('homeworkFilter');
    if (!classFilter) return;
    
    const filterValue = classFilter.value;
    const homeworkItems = document.querySelectorAll('.homework-item');
    
    homeworkItems.forEach(item => {
        const classElement = item.querySelector('.homework-meta .meta-item:nth-child(1)');
        const className = classElement?.textContent || '';
        const classMatch = !filterValue || className.includes(filterValue);
        
        item.style.display = classMatch ? 'block' : 'none';
    });
}

// تحميل جميع المحتويات
async function loadAllContent() {
    try {
        const teacherId = window.AppState.currentUser.user_id;
        
        const { data: allContent, error } = await window.EduPath.supabase
            .from('content')
            .select(`
                *,
                classes!left (
                    name
                )
            `)
            .eq('teacher_id', teacherId)
            .order('created_at', { ascending: false });

        if (error) throw error;

        const container = document.getElementById('allContentTimeline');
        if (!container) return;
        
        container.innerHTML = '';

        if (allContent.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-list"></i>
                    <p>لا يوجد محتوى بعد</p>
                    <button class="btn btn-primary" onclick="switchContentTab('upload')">
                        <i class="fas fa-plus"></i>
                        إضافة محتوى جديد
                    </button>
                </div>
            `;
            return;
        }

        allContent.forEach(content => {
            const timelineItem = document.createElement('div');
            timelineItem.className = 'timeline-content-item';
            
            const isHomework = content.type === 'homework';
            const icon = isHomework ? 'fa-tasks' : 'fa-book-open';
            const typeText = isHomework ? 'واجب' : 'درس';
            
            timelineItem.innerHTML = `
                <div class="timeline-icon">
                    <i class="fas ${icon}"></i>
                </div>
                <div class="timeline-content">
                    <div class="content-header">
                        <h3>${content.title}</h3>
                        <div class="content-meta">
                            <span class="badge ${isHomework ? 'badge-secondary' : 'badge-primary'}">
                                ${typeText}
                            </span>
                            <span class="meta-item">
                                <i class="fas fa-chalkboard"></i>
                                ${content.classes?.name || 'غير محدد'}
                            </span>
                            <span class="meta-item">
                                <i class="far fa-clock"></i>
                                ${window.Helpers.formatDate(content.created_at)}
                            </span>
                        </div>
                    </div>
                    <div class="content-body">
                        <p>${content.description || 'لا يوجد وصف'}</p>
                        ${isHomework && content.due_date ? `
                            <div class="homework-due">
                                <i class="fas fa-calendar-times"></i>
                                <span>تاريخ التسليم: ${new Date(content.due_date).toLocaleDateString('ar-EG')}</span>
                            </div>
                        ` : ''}
                    </div>
                    <div class="content-actions">
                        <button class="btn btn-sm btn-outline" onclick="viewContent('${content.id}')">
                            <i class="fas fa-eye"></i>
                            عرض
                        </button>
                        <button class="btn btn-sm btn-primary" onclick="editContent('${content.id}')">
                            <i class="fas fa-edit"></i>
                            تعديل
                        </button>
                        ${isHomework ? `
                            <button class="btn btn-sm btn-success" onclick="gradeHomework('${content.id}')">
                                <i class="fas fa-star"></i>
                                تقييم
                            </button>
                        ` : ''}
                    </div>
                </div>
            `;
            container.appendChild(timelineItem);
        });

    } catch (error) {
        console.error('Error loading all content:', error);
        window.Helpers.showToast('خطأ في تحميل المحتوى', 'error');
    }
}

// بحث في المحتوى
function searchContent() {
    const searchInput = document.getElementById('contentSearch');
    if (!searchInput) return;
    
    const searchTerm = searchInput.value.toLowerCase();
    const items = document.querySelectorAll('.timeline-content-item');
    
    items.forEach(item => {
        const title = item.querySelector('h3').textContent.toLowerCase();
        const description = item.querySelector('.content-body p').textContent.toLowerCase();
        
        if (title.includes(searchTerm) || description.includes(searchTerm)) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// عرض المحتوى
async function viewContent(contentId) {
    try {
        const { data: content, error } = await window.EduPath.supabase
            .from('content')
            .select(`
                *,
                classes!left (
                    name
                ),
                users!inner (
                    full_name
                )
            `)
            .eq('id', contentId)
            .single();

        if (error) throw error;

        const attachments = content.attachment_url ? content.attachment_url.split(',') : [];
        const isHomework = content.type === 'homework';
        
        let modalContent = `
            <div class="content-view">
                <div class="content-header">
                    <h2>${content.title}</h2>
                    <div class="content-meta">
                        <span class="badge ${isHomework ? 'badge-secondary' : 'badge-primary'}">
                            ${isHomework ? 'واجب' : 'درس'}
                        </span>
                        <span class="meta-item">
                            <i class="fas fa-user"></i>
                            ${content.users.full_name}
                        </span>
                        <span class="meta-item">
                            <i class="fas fa-chalkboard"></i>
                            ${content.classes?.name || 'غير محدد'}
                        </span>
                        <span class="meta-item">
                            <i class="far fa-clock"></i>
                            ${window.Helpers.formatDate(content.created_at)}
                        </span>
                    </div>
                </div>
                
                <div class="content-description">
                    <h4><i class="fas fa-align-left"></i> الوصف</h4>
                    <p>${content.description || 'لا يوجد وصف'}</p>
                </div>
                
                ${isHomework && content.due_date ? `
                    <div class="content-due-date">
                        <h4><i class="fas fa-calendar-times"></i> معلومات الواجب</h4>
                        <div class="due-details">
                            <div class="detail-item">
                                <span class="label">تاريخ التسليم:</span>
                                <span class="value">${new Date(content.due_date).toLocaleDateString('ar-EG')}</span>
                            </div>
                            ${content.max_score ? `
                                <div class="detail-item">
                                    <span class="label">الدرجة الكاملة:</span>
                                    <span class="value">${content.max_score}</span>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                ` : ''}
                
                ${attachments.length > 0 ? `
                    <div class="content-attachments">
                        <h4><i class="fas fa-paperclip"></i> المرفقات (${attachments.length})</h4>
                        <div class="attachments-list">
                            ${attachments.map((url, index) => `
                                <div class="attachment-item">
                                    <i class="fas fa-file"></i>
                                    <a href="${url}" target="_blank" class="attachment-link">
                                        المرفق ${index + 1}
                                    </a>
                                    <button class="btn btn-icon btn-sm" onclick="copyLink('${url}')">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                
                <div class="content-actions">
                    <button class="btn btn-primary" onclick="editContent('${content.id}')">
                        <i class="fas fa-edit"></i>
                        تعديل
                    </button>
                    <button class="btn btn-danger" onclick="deleteContent('${content.id}')">
                        <i class="fas fa-trash"></i>
                        حذف
                    </button>
                </div>
            </div>
        `;

        // عرض في نافذة منبثقة
        showCustomModal(content.title, modalContent);

    } catch (error) {
        console.error('Error viewing content:', error);
        window.Helpers.showToast('خطأ في تحميل المحتوى', 'error');
    }
}

// نسخ رابط
function copyLink(url) {
    navigator.clipboard.writeText(url).then(() => {
        window.Helpers.showToast('تم نسخ الرابط', 'success');
    });
}

// تعديل المحتوى
function editContent(contentId) {
    window.Helpers.showToast('ميزة التعديل قيد التطوير', 'info');
    // سيتم تنفيذها لاحقاً
}

// حذف المحتوى
async function deleteContent(contentId) {
    if (!confirm('هل أنت متأكد من حذف هذا المحتوى؟')) {
        return;
    }

    try {
        const { error } = await window.EduPath.supabase
            .from('content')
            .delete()
            .eq('id', contentId);

        if (error) throw error;

        window.Helpers.showToast('تم حذف المحتوى بنجاح', 'success');
        
        // تحديث البيانات
        await updateContentCounts();
        await loadLessons();
        await loadHomework();
        await loadAllContent();
        await loadRecentContent();

    } catch (error) {
        console.error('Error deleting content:', error);
        window.Helpers.showToast('خطأ في حذف المحتوى', 'error');
    }
}

// تقييم الواجب
function gradeHomework(contentId) {
    window.Helpers.showToast('سيتم فتح صفحة تقييم الواجب', 'info');
    // سيتم تنفيذها في قسم الدرجات
}

// عرض تقديمات الواجب
function viewSubmissions(contentId) {
    window.Helpers.showToast('ميزة عرض التقديمات قيد التطوير', 'info');
    // سيتم تنفيذها لاحقاً
}

// عرض نافذة مخصصة
function showCustomModal(title, content) {
    const modalId = 'customModal';
    let modal = document.getElementById(modalId);
    
    if (!modal) {
        modal = document.createElement('div');
        modal.id = modalId;
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close" onclick="closeModal('${modalId}')">&times;</button>
                </div>
                <div class="modal-body"></div>
            </div>
        `;
        document.body.appendChild(modal);
    }
    
    modal.querySelector('.modal-body').innerHTML = content;
    modal.style.display = 'block';
}

// تصدير الوظائف العامة
window.TeacherContent = {
    initializeContentSection,
    switchContentTab,
    toggleHomeworkFields,
    resetUploadForm,
    loadLessons,
    filterLessons,
    loadHomework,
    filterHomework,
    loadAllContent,
    searchContent,
    viewContent,
    copyLink,
    editContent,
    deleteContent,
    gradeHomework,
    viewSubmissions,
    showCustomModal
};